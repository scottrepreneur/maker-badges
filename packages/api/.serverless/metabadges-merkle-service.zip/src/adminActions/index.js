"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.updateRoots = void 0;
const _ = require("lodash");
const aws_1 = require("../utils/aws");
const governance_1 = require("./governance");
const auctions_1 = require("./auctions");
const constants_1 = require("../constants");
const merkleTree_1 = require("../utils/merkleTree");
async function updateRoots() {
    // saving at least 1 dai in DSR
    console.log({ templateId: 1, dai_saved: 1 });
    // locking Dai in DSR for N (time) periods
    const daiInDsr = [
        { templateId: 2, periods: 3 },
        { templateId: 3, periods: 6 },
    ];
    daiInDsr.map(async (periods) => {
        console.log(periods);
    });
    // transfer N (amount) of Dai
    const daiTransferred = [
        { templateId: 4, amount: 10 },
        { templateId: 5, amount: 100 },
    ];
    daiTransferred.map(async (amount) => {
        console.log(amount);
    });
    // voting on at least N (frequency) governance polls
    const governanceVoteFrequencies = [
        { templateId: 6, frequency: 1 },
        { templateId: 7, frequency: 5 },
        { templateId: 8, frequency: 10 },
        { templateId: 9, frequency: 20 },
        { templateId: 10, frequency: 50 },
        { templateId: 11, frequency: 100 },
    ];
    const govVoteAddresses = await governance_1.allGovernancePollAddresses();
    governanceVoteFrequencies.map(freq => {
        const govVoteAddressList = governance_1.pollVoteAddressesForFrequency(freq.frequency, govVoteAddresses);
        if (govVoteAddressList.addresses && _.size(govVoteAddressList.addresses) > 0) {
            const tree = new merkleTree_1.default(govVoteAddressList.addresses);
            if (process.env.ENVIRONMENT === "production") {
                aws_1.addOrUpdateTemplateRecord(freq.templateId, govVoteAddressList.addresses, tree.getHexRoot(), govVoteAddressList.progress);
            }
            console.log(freq.templateId, tree.getHexRoot() || constants_1.ZERO_ROOT);
        }
        else {
            console.log('No Addresses for template #' + freq.templateId);
            if (process.env.ENVIRONMENT === "production") {
                aws_1.addOrUpdateTemplateRecord(freq.templateId, [], constants_1.ZERO_ROOT, {});
            }
        }
        return;
    });
    // voting on N (frequency) consecutive governance polls
    const consecutiveGovernancePollFrequencies = [
        { templateId: 12, frequency: 2 },
        { templateId: 13, frequency: 5 },
        { templateId: 14, frequency: 10 },
    ];
    const governancePollAddresses = await governance_1.allGovernancePollAddressesWithPollId();
    consecutiveGovernancePollFrequencies.map(freq => {
        const consecutiveAddresses = governance_1.consecutivePollVoteAddressesForFrequency(freq.frequency, governancePollAddresses);
        if (consecutiveAddresses.addresses && _.size(consecutiveAddresses.addresses) > 0) {
            const tree = new merkleTree_1.default(consecutiveAddresses.addresses);
            if (process.env.ENVIRONMENT === "production") {
                aws_1.addOrUpdateTemplateRecord(freq.templateId, consecutiveAddresses.addresses, tree.getHexRoot(), consecutiveAddresses.progress);
            }
            console.log(freq.templateId, tree.getHexRoot() || constants_1.ZERO_ROOT);
        }
        else {
            console.log('No Addresses for template #' + freq.templateId);
            if (process.env.ENVIRONMENT === "production") {
                aws_1.addOrUpdateTemplateRecord(freq.templateId, [], constants_1.ZERO_ROOT, {});
            }
        }
        return;
    });
    // voting on at least N (frequency) executive proposals (spells)
    const executiveSpellFrequencies = [
        { templateId: 15, frequency: 1 },
        { templateId: 16, frequency: 5 },
        { templateId: 17, frequency: 10 },
        { templateId: 18, frequency: 20 },
        { templateId: 19, frequency: 50 },
    ];
    const execSpellAddresses = await governance_1.allExecutiveSpellAddresses();
    executiveSpellFrequencies.map(freq => {
        const execAddresses = governance_1.spellVoteAddressesForFrequency(freq.frequency, execSpellAddresses);
        if (execAddresses.addresses && _.size(execAddresses.addresses) > 0) {
            const tree = new merkleTree_1.default(execAddresses.addresses);
            if (process.env.ENVIRONMENT === "production") {
                aws_1.addOrUpdateTemplateRecord(freq.templateId, execAddresses.addresses || [], tree.getHexRoot() || constants_1.ZERO_ROOT, execAddresses.progress || {});
            }
            console.log(freq.templateId, tree.getHexRoot() || constants_1.ZERO_ROOT);
        }
        else {
            console.log('No Addresses for template #' + freq.templateId);
            if (process.env.ENVIRONMENT === "production") {
                aws_1.addOrUpdateTemplateRecord(freq.templateId, [], constants_1.ZERO_ROOT, {});
            }
        }
        return;
    });
    // early voter on Executive Spell (within 60 minutes of creation)
    const earlyExecutiveVotes = [{ templateId: 20, time: 3600 }];
    const executiveAddressesWithTimestamp = await governance_1.allExecutiveSpellAddressesWithTimestamps();
    earlyExecutiveVotes.map(time => {
        const earlyExecutiveAddresses = governance_1.earlyExecutiveVoteAddressesForTime(time.time, executiveAddressesWithTimestamp);
        if (earlyExecutiveAddresses.addresses && _.size(earlyExecutiveAddresses.addresses) > 0) {
            const tree = new merkleTree_1.default(earlyExecutiveAddresses.addresses);
            if (process.env.ENVIRONMENT === "production") {
                aws_1.addOrUpdateTemplateRecord(time.templateId, earlyExecutiveAddresses.addresses || [], tree.getHexRoot() || constants_1.ZERO_ROOT, earlyExecutiveAddresses.progress || {});
            }
            console.log(time.templateId, tree.getHexRoot() || constants_1.ZERO_ROOT);
        }
        else {
            console.log('No Addresses for template #' + time.templateId);
            if (process.env.ENVIRONMENT === "production") {
                aws_1.addOrUpdateTemplateRecord(time.templateId, [], constants_1.ZERO_ROOT, {});
            }
        }
        return;
    });
    // early voter on governance poll (within 60 minutes of start time)
    const earlyPollVotes = [{ templateId: 21, time: 3600 }];
    const govVoteAddressesWithTimestamp = await governance_1.allGovernancePollAddressesWithTimestamps();
    earlyPollVotes.map(time => {
        const addresses = governance_1.earlyPollVoteAddressesForTime(time.time, govVoteAddressesWithTimestamp);
        if (addresses.addresses && _.size(addresses.addresses) > 0) {
            const tree = new merkleTree_1.default(addresses.addresses);
            if (process.env.ENVIRONMENT === "production") {
                aws_1.addOrUpdateTemplateRecord(time.templateId, addresses.addresses || [], tree.getHexRoot() || constants_1.ZERO_ROOT, addresses.progress || {});
            }
            console.log(time.templateId, tree.getHexRoot() || constants_1.ZERO_ROOT);
        }
        else {
            console.log('No addresses for template #' + time.templateId);
            if (process.env.ENVIRONMENT === "production") {
                aws_1.addOrUpdateTemplateRecord(time.templateId, [], constants_1.ZERO_ROOT, {});
            }
        }
        return;
    });
    // biting at least N (frequency) unsafe Vaults
    const bitingVaultsFrequencies = [
        { templateId: 22, frequency: 1 },
        { templateId: 23, frequency: 10 },
        { templateId: 24, frequency: 50 },
        { templateId: 25, frequency: 100 },
    ];
    const allBiteAddresses = await auctions_1.allBitesAllFlippers();
    bitingVaultsFrequencies.map(freq => {
        const biteAddresses = auctions_1.biteAddressesForFrequency(freq.frequency, allBiteAddresses);
        if (biteAddresses.addresses && _.size(biteAddresses.addresses) > 0) {
            const tree = new merkleTree_1.default(biteAddresses.addresses);
            if (process.env.ENVIRONMENT === "production") {
                aws_1.addOrUpdateTemplateRecord(freq.templateId, biteAddresses.addresses || [], tree.getHexRoot() || constants_1.ZERO_ROOT, biteAddresses.progress || {});
            }
            console.log(freq.templateId, tree.getHexRoot() || constants_1.ZERO_ROOT);
        }
        else {
            console.log('No addresses for template #' + freq.templateId);
            if (process.env.ENVIRONMENT === "production") {
                aws_1.addOrUpdateTemplateRecord(freq.templateId, [], constants_1.ZERO_ROOT, {});
            }
        }
        return;
    });
    // bidding on at least N (frequency) collateral auctions
    const bidCollateralAuctionFrequencies = [
        { templateId: 26, frequency: 1 },
        { templateId: 27, frequency: 5 },
        { templateId: 28, frequency: 10 },
        { templateId: 29, frequency: 25 },
    ];
    const allBidAddressList = await auctions_1.allBidAddresses();
    bidCollateralAuctionFrequencies.map(freq => {
        const bidAddresses = auctions_1.bidAddressesForFrequency(freq.frequency, allBidAddressList);
        if (bidAddresses.addresses && _.size(bidAddresses.addresses) > 0) {
            const tree = new merkleTree_1.default(bidAddresses.addresses);
            if (process.env.ENVIRONMENT === "production") {
                aws_1.addOrUpdateTemplateRecord(freq.templateId, bidAddresses.addresses || [], tree.getHexRoot() || constants_1.ZERO_ROOT, bidAddresses.progress || {});
            }
            console.log(freq.templateId, tree.getHexRoot() || constants_1.ZERO_ROOT);
        }
        else {
            console.log('No Addresses for template #' + freq.templateId);
            if (process.env.ENVIRONMENT === "production") {
                aws_1.addOrUpdateTemplateRecord(freq.templateId, [], constants_1.ZERO_ROOT, {});
            }
        }
        return;
    });
    // winning at least N (frequency) collateral auctions
    const winCollateralAuctionFrequencies = [
        { templateId: 30, frequency: 1 },
        { templateId: 31, frequency: 5 },
        { templateId: 32, frequency: 10 },
        { templateId: 33, frequency: 25 },
    ];
    const allBidGuyAddressList = await auctions_1.allBidGuysAllFlippers();
    winCollateralAuctionFrequencies.map(freq => {
        const bidGuyAddresses = auctions_1.bidGuyAddressesForFrequency(freq.frequency, allBidGuyAddressList);
        if (bidGuyAddresses.addresses && _.size(bidGuyAddresses.addresses) > 0) {
            const tree = new merkleTree_1.default(bidGuyAddresses.addresses);
            if (process.env.ENVIRONMENT === "production") {
                aws_1.addOrUpdateTemplateRecord(freq.templateId, bidGuyAddresses.addresses || [], tree.getHexRoot() || constants_1.ZERO_ROOT, bidGuyAddresses.progress || {});
            }
            console.log(freq.templateId, tree.getHexRoot() || constants_1.ZERO_ROOT);
        }
        else {
            console.log('No Addresses for template #' + freq.templateId);
            if (process.env.ENVIRONMENT === "production") {
                aws_1.addOrUpdateTemplateRecord(freq.templateId, [], constants_1.ZERO_ROOT, {});
            }
        }
    });
}
exports.updateRoots = updateRoots;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi9zcmMvYWRtaW5BY3Rpb25zL2luZGV4LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7OztBQUFBLDRCQUE0QjtBQUM1QixzQ0FBeUQ7QUFDekQsNkNBV3NCO0FBQ3RCLHlDQU9vQjtBQUNwQiw0Q0FBeUM7QUFFekMsb0RBQTZDO0FBRXRDLEtBQUssVUFBVSxXQUFXO0lBQy9CLCtCQUErQjtJQUMvQixPQUFPLENBQUMsR0FBRyxDQUFDLEVBQUUsVUFBVSxFQUFFLENBQUMsRUFBRSxTQUFTLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQztJQUU3QywwQ0FBMEM7SUFDMUMsTUFBTSxRQUFRLEdBQUc7UUFDZixFQUFFLFVBQVUsRUFBRSxDQUFDLEVBQUUsT0FBTyxFQUFFLENBQUMsRUFBRTtRQUM3QixFQUFFLFVBQVUsRUFBRSxDQUFDLEVBQUUsT0FBTyxFQUFFLENBQUMsRUFBRTtLQUM5QixDQUFDO0lBQ0YsUUFBUSxDQUFDLEdBQUcsQ0FBQyxLQUFLLEVBQUMsT0FBTyxFQUFDLEVBQUU7UUFDM0IsT0FBTyxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsQ0FBQztJQUN2QixDQUFDLENBQUMsQ0FBQztJQUVILDZCQUE2QjtJQUM3QixNQUFNLGNBQWMsR0FBRztRQUNyQixFQUFFLFVBQVUsRUFBRSxDQUFDLEVBQUUsTUFBTSxFQUFFLEVBQUUsRUFBRTtRQUM3QixFQUFFLFVBQVUsRUFBRSxDQUFDLEVBQUUsTUFBTSxFQUFFLEdBQUcsRUFBRTtLQUMvQixDQUFDO0lBQ0YsY0FBYyxDQUFDLEdBQUcsQ0FBQyxLQUFLLEVBQUMsTUFBTSxFQUFDLEVBQUU7UUFDaEMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsQ0FBQztJQUN0QixDQUFDLENBQUMsQ0FBQztJQUVILG9EQUFvRDtJQUNwRCxNQUFNLHlCQUF5QixHQUFHO1FBQ2hDLEVBQUUsVUFBVSxFQUFFLENBQUMsRUFBRSxTQUFTLEVBQUUsQ0FBQyxFQUFFO1FBQy9CLEVBQUUsVUFBVSxFQUFFLENBQUMsRUFBRSxTQUFTLEVBQUUsQ0FBQyxFQUFFO1FBQy9CLEVBQUUsVUFBVSxFQUFFLENBQUMsRUFBRSxTQUFTLEVBQUUsRUFBRSxFQUFFO1FBQ2hDLEVBQUUsVUFBVSxFQUFFLENBQUMsRUFBRSxTQUFTLEVBQUUsRUFBRSxFQUFFO1FBQ2hDLEVBQUUsVUFBVSxFQUFFLEVBQUUsRUFBRSxTQUFTLEVBQUUsRUFBRSxFQUFFO1FBQ2pDLEVBQUUsVUFBVSxFQUFFLEVBQUUsRUFBRSxTQUFTLEVBQUUsR0FBRyxFQUFFO0tBQ25DLENBQUM7SUFDRixNQUFNLGdCQUFnQixHQUFHLE1BQU0sdUNBQTBCLEVBQUUsQ0FBQztJQUU1RCx5QkFBeUIsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLEVBQUU7UUFDbkMsTUFBTSxrQkFBa0IsR0FBRywwQ0FBNkIsQ0FBQyxJQUFJLENBQUMsU0FBUyxFQUFFLGdCQUFnQixDQUFDLENBQUM7UUFDM0YsSUFBSSxrQkFBa0IsQ0FBQyxTQUFTLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLEVBQUU7WUFDNUUsTUFBTSxJQUFJLEdBQUcsSUFBSSxvQkFBVSxDQUFDLGtCQUFrQixDQUFDLFNBQVMsQ0FBQyxDQUFDO1lBRTFELElBQUksT0FBTyxDQUFDLEdBQUcsQ0FBQyxXQUFXLEtBQUssWUFBWSxFQUFFO2dCQUM1QywrQkFBeUIsQ0FDdkIsSUFBSSxDQUFDLFVBQVUsRUFDZixrQkFBa0IsQ0FBQyxTQUFTLEVBQzVCLElBQUksQ0FBQyxVQUFVLEVBQUUsRUFDakIsa0JBQWtCLENBQUMsUUFBUSxDQUM1QixDQUFDO2FBQ0g7WUFDRCxPQUFPLENBQUMsR0FBRyxDQUNULElBQUksQ0FBQyxVQUFVLEVBQ2YsSUFBSSxDQUFDLFVBQVUsRUFBRSxJQUFJLHFCQUFTLENBQy9CLENBQUM7U0FDSDthQUFNO1lBQ0wsT0FBTyxDQUFDLEdBQUcsQ0FBQyw2QkFBNkIsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7WUFFN0QsSUFBSSxPQUFPLENBQUMsR0FBRyxDQUFDLFdBQVcsS0FBSyxZQUFZLEVBQUU7Z0JBQzVDLCtCQUF5QixDQUFDLElBQUksQ0FBQyxVQUFVLEVBQUUsRUFBRSxFQUFFLHFCQUFTLEVBQUUsRUFBRSxDQUFDLENBQUM7YUFDL0Q7U0FDRjtRQUVELE9BQU87SUFDVCxDQUFDLENBQUMsQ0FBQztJQUVILHVEQUF1RDtJQUN2RCxNQUFNLG9DQUFvQyxHQUFHO1FBQzNDLEVBQUUsVUFBVSxFQUFFLEVBQUUsRUFBRSxTQUFTLEVBQUUsQ0FBQyxFQUFFO1FBQ2hDLEVBQUUsVUFBVSxFQUFFLEVBQUUsRUFBRSxTQUFTLEVBQUUsQ0FBQyxFQUFFO1FBQ2hDLEVBQUUsVUFBVSxFQUFFLEVBQUUsRUFBRSxTQUFTLEVBQUUsRUFBRSxFQUFFO0tBQ2xDLENBQUM7SUFDRixNQUFNLHVCQUF1QixHQUFHLE1BQU0saURBQW9DLEVBQUUsQ0FBQztJQUU3RSxvQ0FBb0MsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLEVBQUU7UUFDOUMsTUFBTSxvQkFBb0IsR0FBRyxxREFBd0MsQ0FBQyxJQUFJLENBQUMsU0FBUyxFQUFFLHVCQUF1QixDQUFDLENBQUM7UUFFL0csSUFBSSxvQkFBb0IsQ0FBQyxTQUFTLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLEVBQUU7WUFDaEYsTUFBTSxJQUFJLEdBQUcsSUFBSSxvQkFBVSxDQUFDLG9CQUFvQixDQUFDLFNBQVMsQ0FBQyxDQUFDO1lBRTVELElBQUksT0FBTyxDQUFDLEdBQUcsQ0FBQyxXQUFXLEtBQUssWUFBWSxFQUFFO2dCQUM1QywrQkFBeUIsQ0FDdkIsSUFBSSxDQUFDLFVBQVUsRUFDZixvQkFBb0IsQ0FBQyxTQUFTLEVBQzlCLElBQUksQ0FBQyxVQUFVLEVBQUUsRUFDakIsb0JBQW9CLENBQUMsUUFBUSxDQUM5QixDQUFDO2FBQ0g7WUFDRCxPQUFPLENBQUMsR0FBRyxDQUNULElBQUksQ0FBQyxVQUFVLEVBQ2YsSUFBSSxDQUFDLFVBQVUsRUFBRSxJQUFJLHFCQUFTLENBQy9CLENBQUM7U0FDSDthQUFNO1lBQ0wsT0FBTyxDQUFDLEdBQUcsQ0FBQyw2QkFBNkIsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7WUFFN0QsSUFBSSxPQUFPLENBQUMsR0FBRyxDQUFDLFdBQVcsS0FBSyxZQUFZLEVBQUU7Z0JBQzVDLCtCQUF5QixDQUFDLElBQUksQ0FBQyxVQUFVLEVBQUUsRUFBRSxFQUFFLHFCQUFTLEVBQUUsRUFBRSxDQUFDLENBQUM7YUFDL0Q7U0FDRjtRQUVELE9BQU87SUFDVCxDQUFDLENBQUMsQ0FBQztJQUVILGdFQUFnRTtJQUNoRSxNQUFNLHlCQUF5QixHQUFHO1FBQ2hDLEVBQUUsVUFBVSxFQUFFLEVBQUUsRUFBRSxTQUFTLEVBQUUsQ0FBQyxFQUFFO1FBQ2hDLEVBQUUsVUFBVSxFQUFFLEVBQUUsRUFBRSxTQUFTLEVBQUUsQ0FBQyxFQUFFO1FBQ2hDLEVBQUUsVUFBVSxFQUFFLEVBQUUsRUFBRSxTQUFTLEVBQUUsRUFBRSxFQUFFO1FBQ2pDLEVBQUUsVUFBVSxFQUFFLEVBQUUsRUFBRSxTQUFTLEVBQUUsRUFBRSxFQUFFO1FBQ2pDLEVBQUUsVUFBVSxFQUFFLEVBQUUsRUFBRSxTQUFTLEVBQUUsRUFBRSxFQUFFO0tBQ2xDLENBQUM7SUFDRixNQUFNLGtCQUFrQixHQUFHLE1BQU0sdUNBQTBCLEVBQUUsQ0FBQztJQUU5RCx5QkFBeUIsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLEVBQUU7UUFDbkMsTUFBTSxhQUFhLEdBQUcsMkNBQThCLENBQUMsSUFBSSxDQUFDLFNBQVMsRUFBRSxrQkFBa0IsQ0FBQyxDQUFDO1FBRXpGLElBQUksYUFBYSxDQUFDLFNBQVMsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLEVBQUU7WUFDbEUsTUFBTSxJQUFJLEdBQUcsSUFBSSxvQkFBVSxDQUFDLGFBQWEsQ0FBQyxTQUFTLENBQUMsQ0FBQztZQUVyRCxJQUFJLE9BQU8sQ0FBQyxHQUFHLENBQUMsV0FBVyxLQUFLLFlBQVksRUFBRTtnQkFDNUMsK0JBQXlCLENBQ3ZCLElBQUksQ0FBQyxVQUFVLEVBQ2YsYUFBYSxDQUFDLFNBQVMsSUFBSSxFQUFFLEVBQzdCLElBQUksQ0FBQyxVQUFVLEVBQUUsSUFBSSxxQkFBUyxFQUM5QixhQUFhLENBQUMsUUFBUSxJQUFJLEVBQUUsQ0FDN0IsQ0FBQzthQUNIO1lBQ0QsT0FBTyxDQUFDLEdBQUcsQ0FDVCxJQUFJLENBQUMsVUFBVSxFQUNmLElBQUksQ0FBQyxVQUFVLEVBQUUsSUFBSSxxQkFBUyxDQUMvQixDQUFDO1NBQ0g7YUFBTTtZQUNMLE9BQU8sQ0FBQyxHQUFHLENBQUMsNkJBQTZCLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO1lBRTdELElBQUksT0FBTyxDQUFDLEdBQUcsQ0FBQyxXQUFXLEtBQUssWUFBWSxFQUFFO2dCQUM1QywrQkFBeUIsQ0FBQyxJQUFJLENBQUMsVUFBVSxFQUFFLEVBQUUsRUFBRSxxQkFBUyxFQUFFLEVBQUUsQ0FBQyxDQUFDO2FBQy9EO1NBQ0Y7UUFFRCxPQUFPO0lBQ1QsQ0FBQyxDQUFDLENBQUM7SUFFSCxpRUFBaUU7SUFDakUsTUFBTSxtQkFBbUIsR0FBRyxDQUFDLEVBQUUsVUFBVSxFQUFFLEVBQUUsRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLENBQUMsQ0FBQztJQUM3RCxNQUFNLCtCQUErQixHQUFHLE1BQU0scURBQXdDLEVBQUUsQ0FBQztJQUV6RixtQkFBbUIsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLEVBQUU7UUFDN0IsTUFBTSx1QkFBdUIsR0FBRywrQ0FBa0MsQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFFLCtCQUErQixDQUFDLENBQUM7UUFFL0csSUFBSSx1QkFBdUIsQ0FBQyxTQUFTLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLEVBQUU7WUFDdEYsTUFBTSxJQUFJLEdBQUcsSUFBSSxvQkFBVSxDQUFDLHVCQUF1QixDQUFDLFNBQVMsQ0FBQyxDQUFDO1lBRS9ELElBQUksT0FBTyxDQUFDLEdBQUcsQ0FBQyxXQUFXLEtBQUssWUFBWSxFQUFFO2dCQUM1QywrQkFBeUIsQ0FDdkIsSUFBSSxDQUFDLFVBQVUsRUFDZix1QkFBdUIsQ0FBQyxTQUFTLElBQUksRUFBRSxFQUN2QyxJQUFJLENBQUMsVUFBVSxFQUFFLElBQUkscUJBQVMsRUFDOUIsdUJBQXVCLENBQUMsUUFBUSxJQUFJLEVBQUUsQ0FDdkMsQ0FBQzthQUNIO1lBQ0QsT0FBTyxDQUFDLEdBQUcsQ0FDVCxJQUFJLENBQUMsVUFBVSxFQUNmLElBQUksQ0FBQyxVQUFVLEVBQUUsSUFBSSxxQkFBUyxDQUMvQixDQUFDO1NBQ0g7YUFBTTtZQUNMLE9BQU8sQ0FBQyxHQUFHLENBQUMsNkJBQTZCLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFBO1lBRTVELElBQUksT0FBTyxDQUFDLEdBQUcsQ0FBQyxXQUFXLEtBQUssWUFBWSxFQUFFO2dCQUM1QywrQkFBeUIsQ0FBQyxJQUFJLENBQUMsVUFBVSxFQUFFLEVBQUUsRUFBRSxxQkFBUyxFQUFFLEVBQUUsQ0FBQyxDQUFDO2FBQy9EO1NBQ0Y7UUFFRCxPQUFPO0lBQ1QsQ0FBQyxDQUFDLENBQUM7SUFFSCxtRUFBbUU7SUFDbkUsTUFBTSxjQUFjLEdBQUcsQ0FBQyxFQUFFLFVBQVUsRUFBRSxFQUFFLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxDQUFDLENBQUM7SUFDeEQsTUFBTSw2QkFBNkIsR0FBRyxNQUFNLHFEQUF3QyxFQUFFLENBQUE7SUFFdEYsY0FBYyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsRUFBRTtRQUN4QixNQUFNLFNBQVMsR0FBRywwQ0FBNkIsQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFFLDZCQUE2QixDQUFDLENBQUM7UUFDMUYsSUFBSSxTQUFTLENBQUMsU0FBUyxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsRUFBRTtZQUMxRCxNQUFNLElBQUksR0FBRyxJQUFJLG9CQUFVLENBQUMsU0FBUyxDQUFDLFNBQVMsQ0FBQyxDQUFDO1lBRWpELElBQUksT0FBTyxDQUFDLEdBQUcsQ0FBQyxXQUFXLEtBQUssWUFBWSxFQUFFO2dCQUM1QywrQkFBeUIsQ0FDdkIsSUFBSSxDQUFDLFVBQVUsRUFDZixTQUFTLENBQUMsU0FBUyxJQUFJLEVBQUUsRUFDekIsSUFBSSxDQUFDLFVBQVUsRUFBRSxJQUFJLHFCQUFTLEVBQzlCLFNBQVMsQ0FBQyxRQUFRLElBQUksRUFBRSxDQUN6QixDQUFDO2FBQ0g7WUFDRCxPQUFPLENBQUMsR0FBRyxDQUNULElBQUksQ0FBQyxVQUFVLEVBQ2YsSUFBSSxDQUFDLFVBQVUsRUFBRSxJQUFJLHFCQUFTLENBQy9CLENBQUM7U0FDSDthQUFNO1lBQ0wsT0FBTyxDQUFDLEdBQUcsQ0FBQyw2QkFBNkIsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7WUFFN0QsSUFBSSxPQUFPLENBQUMsR0FBRyxDQUFDLFdBQVcsS0FBSyxZQUFZLEVBQUU7Z0JBQzVDLCtCQUF5QixDQUFDLElBQUksQ0FBQyxVQUFVLEVBQUUsRUFBRSxFQUFFLHFCQUFTLEVBQUUsRUFBRSxDQUFDLENBQUM7YUFDL0Q7U0FDRjtRQUVELE9BQU87SUFDVCxDQUFDLENBQUMsQ0FBQztJQUVILDhDQUE4QztJQUM5QyxNQUFNLHVCQUF1QixHQUFHO1FBQzlCLEVBQUUsVUFBVSxFQUFFLEVBQUUsRUFBRSxTQUFTLEVBQUUsQ0FBQyxFQUFFO1FBQ2hDLEVBQUUsVUFBVSxFQUFFLEVBQUUsRUFBRSxTQUFTLEVBQUUsRUFBRSxFQUFFO1FBQ2pDLEVBQUUsVUFBVSxFQUFFLEVBQUUsRUFBRSxTQUFTLEVBQUUsRUFBRSxFQUFFO1FBQ2pDLEVBQUUsVUFBVSxFQUFFLEVBQUUsRUFBRSxTQUFTLEVBQUUsR0FBRyxFQUFFO0tBQ25DLENBQUM7SUFDRixNQUFNLGdCQUFnQixHQUFHLE1BQU0sOEJBQW1CLEVBQUUsQ0FBQztJQUVyRCx1QkFBdUIsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLEVBQUU7UUFDakMsTUFBTSxhQUFhLEdBQUcsb0NBQXlCLENBQUMsSUFBSSxDQUFDLFNBQVMsRUFBRSxnQkFBZ0IsQ0FBQyxDQUFDO1FBRWxGLElBQUksYUFBYSxDQUFDLFNBQVMsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLEVBQUU7WUFDbEUsTUFBTSxJQUFJLEdBQUcsSUFBSSxvQkFBVSxDQUFDLGFBQWEsQ0FBQyxTQUFTLENBQUMsQ0FBQztZQUVyRCxJQUFJLE9BQU8sQ0FBQyxHQUFHLENBQUMsV0FBVyxLQUFLLFlBQVksRUFBRTtnQkFDNUMsK0JBQXlCLENBQ3ZCLElBQUksQ0FBQyxVQUFVLEVBQ2YsYUFBYSxDQUFDLFNBQVMsSUFBSSxFQUFFLEVBQzdCLElBQUksQ0FBQyxVQUFVLEVBQUUsSUFBSSxxQkFBUyxFQUM5QixhQUFhLENBQUMsUUFBUSxJQUFJLEVBQUUsQ0FDN0IsQ0FBQzthQUNIO1lBQ0QsT0FBTyxDQUFDLEdBQUcsQ0FDVCxJQUFJLENBQUMsVUFBVSxFQUNmLElBQUksQ0FBQyxVQUFVLEVBQUUsSUFBSSxxQkFBUyxDQUMvQixDQUFDO1NBQ0g7YUFBTTtZQUNMLE9BQU8sQ0FBQyxHQUFHLENBQUMsNkJBQTZCLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO1lBRTdELElBQUksT0FBTyxDQUFDLEdBQUcsQ0FBQyxXQUFXLEtBQUssWUFBWSxFQUFFO2dCQUM1QywrQkFBeUIsQ0FBQyxJQUFJLENBQUMsVUFBVSxFQUFFLEVBQUUsRUFBRSxxQkFBUyxFQUFFLEVBQUUsQ0FBQyxDQUFDO2FBQy9EO1NBQ0Y7UUFFRCxPQUFPO0lBQ1QsQ0FBQyxDQUFDLENBQUM7SUFFSCx3REFBd0Q7SUFDeEQsTUFBTSwrQkFBK0IsR0FBRztRQUN0QyxFQUFFLFVBQVUsRUFBRSxFQUFFLEVBQUUsU0FBUyxFQUFFLENBQUMsRUFBRTtRQUNoQyxFQUFFLFVBQVUsRUFBRSxFQUFFLEVBQUUsU0FBUyxFQUFFLENBQUMsRUFBRTtRQUNoQyxFQUFFLFVBQVUsRUFBRSxFQUFFLEVBQUUsU0FBUyxFQUFFLEVBQUUsRUFBRTtRQUNqQyxFQUFFLFVBQVUsRUFBRSxFQUFFLEVBQUUsU0FBUyxFQUFFLEVBQUUsRUFBRTtLQUNsQyxDQUFDO0lBQ0YsTUFBTSxpQkFBaUIsR0FBRyxNQUFNLDBCQUFlLEVBQUUsQ0FBQztJQUVsRCwrQkFBK0IsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLEVBQUU7UUFDekMsTUFBTSxZQUFZLEdBQUcsbUNBQXdCLENBQUMsSUFBSSxDQUFDLFNBQVMsRUFBRSxpQkFBaUIsQ0FBQyxDQUFBO1FBRWhGLElBQUksWUFBWSxDQUFDLFNBQVMsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLEVBQUU7WUFFaEUsTUFBTSxJQUFJLEdBQUcsSUFBSSxvQkFBVSxDQUFDLFlBQVksQ0FBQyxTQUFTLENBQUMsQ0FBQztZQUVwRCxJQUFJLE9BQU8sQ0FBQyxHQUFHLENBQUMsV0FBVyxLQUFLLFlBQVksRUFBRTtnQkFDNUMsK0JBQXlCLENBQ3ZCLElBQUksQ0FBQyxVQUFVLEVBQ2YsWUFBWSxDQUFDLFNBQVMsSUFBSSxFQUFFLEVBQzVCLElBQUksQ0FBQyxVQUFVLEVBQUUsSUFBSSxxQkFBUyxFQUM5QixZQUFZLENBQUMsUUFBUSxJQUFJLEVBQUUsQ0FDNUIsQ0FBQzthQUNIO1lBRUQsT0FBTyxDQUFDLEdBQUcsQ0FDVCxJQUFJLENBQUMsVUFBVSxFQUNmLElBQUksQ0FBQyxVQUFVLEVBQUUsSUFBSSxxQkFBUyxDQUMvQixDQUFDO1NBQ0g7YUFBTTtZQUNMLE9BQU8sQ0FBQyxHQUFHLENBQUMsNkJBQTZCLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO1lBRTdELElBQUksT0FBTyxDQUFDLEdBQUcsQ0FBQyxXQUFXLEtBQUssWUFBWSxFQUFFO2dCQUM1QywrQkFBeUIsQ0FBQyxJQUFJLENBQUMsVUFBVSxFQUFFLEVBQUUsRUFBRSxxQkFBUyxFQUFFLEVBQUUsQ0FBQyxDQUFDO2FBQy9EO1NBQ0Y7UUFFRCxPQUFPO0lBQ1QsQ0FBQyxDQUFDLENBQUM7SUFFSCxxREFBcUQ7SUFDckQsTUFBTSwrQkFBK0IsR0FBRztRQUN0QyxFQUFFLFVBQVUsRUFBRSxFQUFFLEVBQUUsU0FBUyxFQUFFLENBQUMsRUFBRTtRQUNoQyxFQUFFLFVBQVUsRUFBRSxFQUFFLEVBQUUsU0FBUyxFQUFFLENBQUMsRUFBRTtRQUNoQyxFQUFFLFVBQVUsRUFBRSxFQUFFLEVBQUUsU0FBUyxFQUFFLEVBQUUsRUFBRTtRQUNqQyxFQUFFLFVBQVUsRUFBRSxFQUFFLEVBQUUsU0FBUyxFQUFFLEVBQUUsRUFBRTtLQUNsQyxDQUFDO0lBQ0YsTUFBTSxvQkFBb0IsR0FBRyxNQUFNLGdDQUFxQixFQUFFLENBQUM7SUFFM0QsK0JBQStCLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxFQUFFO1FBQ3pDLE1BQU0sZUFBZSxHQUFHLHNDQUEyQixDQUFDLElBQUksQ0FBQyxTQUFTLEVBQUUsb0JBQW9CLENBQUMsQ0FBQTtRQUN6RixJQUFJLGVBQWUsQ0FBQyxTQUFTLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxFQUFFO1lBQ3RFLE1BQU0sSUFBSSxHQUFHLElBQUksb0JBQVUsQ0FBQyxlQUFlLENBQUMsU0FBUyxDQUFDLENBQUM7WUFFdkQsSUFBSSxPQUFPLENBQUMsR0FBRyxDQUFDLFdBQVcsS0FBSyxZQUFZLEVBQUU7Z0JBQzVDLCtCQUF5QixDQUN2QixJQUFJLENBQUMsVUFBVSxFQUNmLGVBQWUsQ0FBQyxTQUFTLElBQUksRUFBRSxFQUMvQixJQUFJLENBQUMsVUFBVSxFQUFFLElBQUkscUJBQVMsRUFDOUIsZUFBZSxDQUFDLFFBQVEsSUFBSSxFQUFFLENBQy9CLENBQUM7YUFDSDtZQUVELE9BQU8sQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLFVBQVUsRUFBRSxJQUFJLENBQUMsVUFBVSxFQUFFLElBQUkscUJBQVMsQ0FBQyxDQUFDO1NBQzlEO2FBQU07WUFDTCxPQUFPLENBQUMsR0FBRyxDQUFDLDZCQUE2QixHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQztZQUU3RCxJQUFJLE9BQU8sQ0FBQyxHQUFHLENBQUMsV0FBVyxLQUFLLFlBQVksRUFBRTtnQkFDNUMsK0JBQXlCLENBQUMsSUFBSSxDQUFDLFVBQVUsRUFBRSxFQUFFLEVBQUUscUJBQVMsRUFBRSxFQUFFLENBQUMsQ0FBQzthQUMvRDtTQUNGO0lBQ0gsQ0FBQyxDQUFDLENBQUM7QUFDTCxDQUFDO0FBeFRELGtDQXdUQyJ9