"use strict";
var __await = (this && this.__await) || function (v) { return this instanceof __await ? (this.v = v, this) : new __await(v); }
var __asyncGenerator = (this && this.__asyncGenerator) || function (thisArg, _arguments, generator) {
    if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
    var g = generator.apply(thisArg, _arguments || []), i, q = [];
    return i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i;
    function verb(n) { if (g[n]) i[n] = function (v) { return new Promise(function (a, b) { q.push([n, v, a, b]) > 1 || resume(n, v); }); }; }
    function resume(n, v) { try { step(g[n](v)); } catch (e) { settle(q[0][3], e); } }
    function step(r) { r.value instanceof __await ? Promise.resolve(r.value.v).then(fulfill, reject) : settle(q[0][2], r); }
    function fulfill(value) { resume("next", value); }
    function reject(value) { resume("throw", value); }
    function settle(f, v) { if (f(v), q.shift(), q.length) resume(q[0][0], q[0][1]); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.bidGuyAddressesForFrequency = exports.allBidGuyAddresses = exports.allBidGuysAllFlippers = exports.bidAddressesForFrequency = exports.allBidAddresses = exports.biteAddressesForFrequency = exports.allBitesAllFlippers = void 0;
const auctions_1 = require("../apollo/queries/auctions");
const clients_1 = require("../apollo/clients");
const utils_1 = require("../utils");
const constants_1 = require("../constants");
const R = require("ramda");
const _ = require("lodash");
const makerAllBitesQuery = function (step = 0, collateral) {
    return __asyncGenerator(this, arguments, function* () {
        const query = yield __await(clients_1.makerClient.query({
            query: auctions_1.ALL_BITES_QUERY,
            fetchPolicy: "cache-first",
            variables: { offset: step * 10000, collateral: collateral },
        }));
        ++step;
        const hasNextPage = R.prop("hasNextPage", query.data.allBites.pageInfo);
        if (!hasNextPage)
            return yield __await({ step, query });
        yield yield __await({ step, query, hasNextPage });
    });
};
function allBiteAddresses(flipper) {
    return new Promise(async (resolve, reject) => {
        let allResults = [];
        // Generator Function
        let query = makerAllBitesQuery(0, flipper);
        // Invoke GenFunc and start process
        let resultSet = await query.next();
        let nextPage = R.prop("hasNextPage", resultSet.value);
        do {
            const nodes = R.prop("nodes", resultSet.value.query.data.allBites);
            if (R.length(nodes) > 0)
                allResults.push(_.map(nodes, "tx.txFrom"));
            if (nextPage)
                resultSet = await query.next();
        } while (resultSet.done === false);
        // Resolve Promise
        resolve(allResults);
    });
}
exports.allBitesAllFlippers = async () => {
    const results = await Promise.all(R.map(allBiteAddresses, Object.keys(constants_1.collateralFlippers)));
    return _.flattenDeep(results);
};
function biteAddressesForFrequency(frequency, biteAddresses) {
    const biteFreq = utils_1.addressListFilteredByFrequency(biteAddresses);
    const greaterThanOrEqualToFrequency = (x) => {
        return x.frequency >= frequency;
    };
    const _addressList = _.filter(biteFreq, greaterThanOrEqualToFrequency);
    const _addresses = _.map(_addressList, 'address');
    const _progress = utils_1.mapFrequenciesToProgressObject(biteFreq, frequency);
    return { addresses: _addresses, progress: _progress };
}
exports.biteAddressesForFrequency = biteAddressesForFrequency;
const makerAllFlipBidsQuery = function (step = 0) {
    return __asyncGenerator(this, arguments, function* () {
        const query = yield __await(clients_1.makerClient.query({
            query: auctions_1.ALL_FLIP_BIDS_QUERY,
            fetchPolicy: "cache-first",
            variables: { offset: step * constants_1.BATCH_QUERIES },
        }));
        ++step;
        const hasNextPage = R.prop("hasNextPage", query.data.allFlipBidEvents.pageInfo);
        yield yield __await({ step, query, hasNextPage });
        if (!hasNextPage)
            return yield __await({ step, query });
    });
};
function allBidAddresses() {
    return new Promise(async (resolve, reject) => {
        const allResults = [];
        // Generator Function
        let query = makerAllFlipBidsQuery(0);
        // Invoke GenFunc and start process
        let resultSet = await query.next();
        // Deff
        const fillResultsArray = eventNodes => {
            eventNodes.map((bid) => {
                if (bid.act === "TEND" || bid.act === "DENT") {
                    allResults.push(R.prop("txFrom", bid.tx.nodes[0]));
                }
                return;
            });
        };
        // Loop
        do {
            const nodes = R.prop("nodes", resultSet.value.query.data.allFlipBidEvents);
            if (R.length(nodes) > 0)
                fillResultsArray(nodes);
            if (resultSet.value.hasNextPage)
                resultSet = await query.next();
        } while (resultSet.done === false);
        // Resolve Promise
        resolve(allResults);
    });
}
exports.allBidAddresses = allBidAddresses;
// for now, a tend and dent on the same auction are counted as 2 bids
function bidAddressesForFrequency(frequency, addressList) {
    const bidFreq = utils_1.addressListFilteredByFrequency(addressList);
    const greaterThanOrEqualToFrequency = (x) => {
        return x.frequency >= frequency;
    };
    const _addressList = _.filter(bidFreq, greaterThanOrEqualToFrequency);
    const _addresses = _.map(_addressList, 'address');
    const _progress = utils_1.mapFrequenciesToProgressObject(bidFreq, frequency);
    return {
        addresses: _addresses,
        progress: _progress,
    };
}
exports.bidAddressesForFrequency = bidAddressesForFrequency;
const makerAllFlipWinsQuery = function (step = 0, flipper) {
    return __asyncGenerator(this, arguments, function* () {
        const query = yield __await(clients_1.makerClient.query({
            query: auctions_1.ALL_FLIP_WINS_QUERY,
            fetchPolicy: "cache-first",
            variables: {
                offset: step * constants_1.BATCH_QUERIES,
                flipper: flipper,
            },
        }));
        ++step;
        const hasNextPage = R.prop("hasNextPage", query.data.allFlipBidGuys.pageInfo);
        if (!hasNextPage)
            return yield __await({ step, query });
        yield yield __await({ step, query, hasNextPage });
    });
};
const addressListFilteredByBidId = (list) => {
    return _.map(_.uniq(list), ((x) => {
        return {
            address: x.guy,
            frequency: _.size(_.filter(list, (bid) => {
                // get pollIds for current address
                return bid.guy === x.guy;
            }))
        };
    }));
};
exports.allBidGuysAllFlippers = async () => {
    const results = await Promise.all(R.map(allBidGuyAddresses, Object.keys(constants_1.collateralFlippers)));
    return _.flattenDeep(results);
};
async function allBidGuyAddresses(flipper) {
    return new Promise(async (resolve, reject) => {
        const allResults = [];
        // Generator Function
        let query = makerAllFlipWinsQuery(0, constants_1.collateralFlippers[flipper]);
        // Invoke GenFunc and start process
        let resultSet = await query.next();
        // Deff
        const fillResultsArray = eventNodes => {
            eventNodes.map((bid) => {
                allResults.push({
                    guy: R.prop("guy", bid),
                    bidId: R.prop("bidId", bid)
                });
            });
        };
        // Loop
        do {
            const nodes = R.prop("nodes", resultSet.value.query.data.allFlipBidGuys);
            if (R.length(nodes) > 0)
                fillResultsArray(nodes);
            if (resultSet.value.hasNextPage)
                resultSet = await query.next();
        } while (resultSet.done === false);
        const zeroPred = R.whereEq({ guy: "0x0000000000000000000000000000000000000000" });
        const sorted = _.orderBy(allResults, ['bidId']);
        const zeroIndexes = _.keys(_.pickBy(sorted, zeroPred));
        const indexes = _.map(zeroIndexes, (x) => Number(++x));
        const filter = _.map(indexes, idx => sorted[idx]);
        // allResults.findIndex(a => a["bidId"] === e["bidId"]) === i;
        const filteredFrequencies = addressListFilteredByBidId(filter);
        // Resolve Promise
        resolve(filteredFrequencies);
    });
}
exports.allBidGuyAddresses = allBidGuyAddresses;
function bidGuyAddressesForFrequency(frequency, addressList) {
    // const bidGuyFreq = await allBidGuysAllFlippers();
    const greaterThanOrEqualToFrequency = (x) => {
        return x.frequency >= frequency;
    };
    const _addressList = _.filter(addressList, greaterThanOrEqualToFrequency);
    const _addresses = _.map(_addressList, 'address');
    const _progress = utils_1.mapFrequenciesToProgressObject(addressList, frequency);
    return {
        addresses: _addresses,
        progress: _progress,
    };
}
exports.bidGuyAddressesForFrequency = bidGuyAddressesForFrequency;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYXVjdGlvbnMuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi9zcmMvYWRtaW5BY3Rpb25zL2F1Y3Rpb25zLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7OztBQUFBLHlEQUlvQztBQUNwQywrQ0FBZ0Q7QUFDaEQsb0NBR2tCO0FBQ2xCLDRDQUdzQjtBQUN0QiwyQkFBMkI7QUFDM0IsNEJBQTRCO0FBRTVCLE1BQU0sa0JBQWtCLEdBQUcsVUFBaUIsSUFBSSxHQUFHLENBQUMsRUFBRSxVQUFrQjs7UUFDdEUsTUFBTSxLQUFLLEdBQUcsY0FBTSxxQkFBVyxDQUFDLEtBQUssQ0FBQztZQUNwQyxLQUFLLEVBQUUsMEJBQWU7WUFDdEIsV0FBVyxFQUFFLGFBQWE7WUFDMUIsU0FBUyxFQUFFLEVBQUUsTUFBTSxFQUFFLElBQUksR0FBRyxLQUFLLEVBQUUsVUFBVSxFQUFFLFVBQVUsRUFBRTtTQUM1RCxDQUFDLENBQUEsQ0FBQztRQUVILEVBQUUsSUFBSSxDQUFDO1FBRVAsTUFBTSxXQUFXLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxhQUFhLEVBQUUsS0FBSyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLENBQUM7UUFFeEUsSUFBSSxDQUFDLFdBQVc7WUFBRSxxQkFBTyxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsRUFBQztRQUV6QyxvQkFBTSxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsV0FBVyxFQUFFLENBQUEsQ0FBQztJQUNyQyxDQUFDO0NBQUEsQ0FBQztBQUVGLFNBQVMsZ0JBQWdCLENBQUMsT0FBZTtJQUN2QyxPQUFPLElBQUksT0FBTyxDQUFDLEtBQUssRUFBRSxPQUFPLEVBQUUsTUFBTSxFQUFFLEVBQUU7UUFDM0MsSUFBSSxVQUFVLEdBQVUsRUFBRSxDQUFDO1FBRTNCLHFCQUFxQjtRQUNyQixJQUFJLEtBQUssR0FBRyxrQkFBa0IsQ0FBQyxDQUFDLEVBQUUsT0FBTyxDQUFDLENBQUM7UUFFM0MsbUNBQW1DO1FBQ25DLElBQUksU0FBUyxHQUFHLE1BQU0sS0FBSyxDQUFDLElBQUksRUFBRSxDQUFDO1FBQ25DLElBQUksUUFBUSxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsYUFBYSxFQUFFLFNBQVMsQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUV0RCxHQUFHO1lBQ0QsTUFBTSxLQUFLLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUUsU0FBUyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1lBRW5FLElBQUksQ0FBQyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDO2dCQUNyQixVQUFVLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsS0FBSyxFQUFFLFdBQVcsQ0FBQyxDQUFDLENBQUM7WUFFN0MsSUFBSSxRQUFRO2dCQUNWLFNBQVMsR0FBRyxNQUFNLEtBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQztTQUVsQyxRQUFRLFNBQVMsQ0FBQyxJQUFJLEtBQUssS0FBSyxFQUFFO1FBRW5DLGtCQUFrQjtRQUNsQixPQUFPLENBQUMsVUFBVSxDQUFDLENBQUM7SUFDdEIsQ0FBQyxDQUFDLENBQUM7QUFDTCxDQUFDO0FBRVksUUFBQSxtQkFBbUIsR0FBRyxLQUFLLElBQUksRUFBRTtJQUM1QyxNQUFNLE9BQU8sR0FBRyxNQUFNLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxnQkFBZ0IsRUFBRSxNQUFNLENBQUMsSUFBSSxDQUFDLDhCQUFrQixDQUFDLENBQUMsQ0FBQyxDQUFDO0lBRTVGLE9BQU8sQ0FBQyxDQUFDLFdBQVcsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUNoQyxDQUFDLENBQUM7QUFFRixTQUFnQix5QkFBeUIsQ0FDdkMsU0FBaUIsRUFDakIsYUFBb0I7SUFFcEIsTUFBTSxRQUFRLEdBQUcsc0NBQThCLENBQUMsYUFBYSxDQUFDLENBQUE7SUFFOUQsTUFBTSw2QkFBNkIsR0FBRyxDQUFDLENBQXlDLEVBQUUsRUFBRTtRQUNsRixPQUFPLENBQUMsQ0FBQyxTQUFTLElBQUksU0FBUyxDQUFDO0lBQ2xDLENBQUMsQ0FBQTtJQUVELE1BQU0sWUFBWSxHQUFHLENBQUMsQ0FBQyxNQUFNLENBQUMsUUFBUSxFQUFFLDZCQUE2QixDQUFDLENBQUE7SUFDdEUsTUFBTSxVQUFVLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxZQUFZLEVBQUUsU0FBUyxDQUFDLENBQUE7SUFFakQsTUFBTSxTQUFTLEdBQUcsc0NBQThCLENBQUMsUUFBUSxFQUFFLFNBQVMsQ0FBQyxDQUFDO0lBRXRFLE9BQU8sRUFBRSxTQUFTLEVBQUUsVUFBVSxFQUFFLFFBQVEsRUFBRSxTQUFTLEVBQUUsQ0FBQTtBQUN2RCxDQUFDO0FBaEJELDhEQWdCQztBQUVELE1BQU0scUJBQXFCLEdBQUcsVUFBaUIsSUFBSSxHQUFHLENBQUM7O1FBQ3JELE1BQU0sS0FBSyxHQUFHLGNBQU0scUJBQVcsQ0FBQyxLQUFLLENBQUM7WUFDcEMsS0FBSyxFQUFFLDhCQUFtQjtZQUMxQixXQUFXLEVBQUUsYUFBYTtZQUMxQixTQUFTLEVBQUUsRUFBRSxNQUFNLEVBQUUsSUFBSSxHQUFHLHlCQUFhLEVBQUU7U0FDNUMsQ0FBQyxDQUFBLENBQUM7UUFFSCxFQUFFLElBQUksQ0FBQztRQUVQLE1BQU0sV0FBVyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsYUFBYSxFQUFFLEtBQUssQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsUUFBUSxDQUFDLENBQUM7UUFFaEYsb0JBQU0sRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLFdBQVcsRUFBRSxDQUFBLENBQUM7UUFFbkMsSUFBSSxDQUFDLFdBQVc7WUFBRSxxQkFBTyxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsRUFBQztJQUMzQyxDQUFDO0NBQUEsQ0FBQztBQUVGLFNBQWdCLGVBQWU7SUFDN0IsT0FBTyxJQUFJLE9BQU8sQ0FBQyxLQUFLLEVBQUUsT0FBTyxFQUFFLE1BQU0sRUFBRSxFQUFFO1FBQzNDLE1BQU0sVUFBVSxHQUFVLEVBQUUsQ0FBQztRQUU3QixxQkFBcUI7UUFDckIsSUFBSSxLQUFLLEdBQUcscUJBQXFCLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFFckMsbUNBQW1DO1FBQ25DLElBQUksU0FBUyxHQUFHLE1BQU0sS0FBSyxDQUFDLElBQUksRUFBRSxDQUFDO1FBRW5DLE9BQU87UUFDUCxNQUFNLGdCQUFnQixHQUFHLFVBQVUsQ0FBQyxFQUFFO1lBQ3BDLFVBQVUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFRLEVBQUUsRUFBRTtnQkFDMUIsSUFBSSxHQUFHLENBQUMsR0FBRyxLQUFLLE1BQU0sSUFBSSxHQUFHLENBQUMsR0FBRyxLQUFLLE1BQU0sRUFBRTtvQkFDNUMsVUFBVSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFFBQVEsRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7aUJBQ3BEO2dCQUVELE9BQU87WUFDVCxDQUFDLENBQUMsQ0FBQztRQUNMLENBQUMsQ0FBQztRQUVGLE9BQU87UUFDUCxHQUFHO1lBQ0QsTUFBTSxLQUFLLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUUsU0FBUyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLENBQUM7WUFFM0UsSUFBSSxDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUM7Z0JBQ3JCLGdCQUFnQixDQUFDLEtBQUssQ0FBQyxDQUFDO1lBRTFCLElBQUksU0FBUyxDQUFDLEtBQUssQ0FBQyxXQUFXO2dCQUM3QixTQUFTLEdBQUcsTUFBTSxLQUFLLENBQUMsSUFBSSxFQUFFLENBQUM7U0FFbEMsUUFBUSxTQUFTLENBQUMsSUFBSSxLQUFLLEtBQUssRUFBRTtRQUVuQyxrQkFBa0I7UUFDbEIsT0FBTyxDQUFDLFVBQVUsQ0FBQyxDQUFDO0lBQ3RCLENBQUMsQ0FBQyxDQUFDO0FBQ0wsQ0FBQztBQXBDRCwwQ0FvQ0M7QUFFRCxxRUFBcUU7QUFDckUsU0FBZ0Isd0JBQXdCLENBQ3RDLFNBQWlCLEVBQ2pCLFdBQXFCO0lBR3JCLE1BQU0sT0FBTyxHQUFHLHNDQUE4QixDQUFDLFdBQVcsQ0FBQyxDQUFDO0lBRTVELE1BQU0sNkJBQTZCLEdBQUcsQ0FBQyxDQUF5QyxFQUFFLEVBQUU7UUFDbEYsT0FBTyxDQUFDLENBQUMsU0FBUyxJQUFJLFNBQVMsQ0FBQztJQUNsQyxDQUFDLENBQUE7SUFFRCxNQUFNLFlBQVksR0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDLE9BQU8sRUFBRSw2QkFBNkIsQ0FBQyxDQUFBO0lBQ3JFLE1BQU0sVUFBVSxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsWUFBWSxFQUFFLFNBQVMsQ0FBQyxDQUFBO0lBRWpELE1BQU0sU0FBUyxHQUFHLHNDQUE4QixDQUFDLE9BQU8sRUFBRSxTQUFTLENBQUMsQ0FBQztJQUVyRSxPQUFPO1FBQ0wsU0FBUyxFQUFFLFVBQVU7UUFDckIsUUFBUSxFQUFFLFNBQVM7S0FDcEIsQ0FBQztBQUNKLENBQUM7QUFwQkQsNERBb0JDO0FBRUQsTUFBTSxxQkFBcUIsR0FBRyxVQUFpQixJQUFJLEdBQUcsQ0FBQyxFQUFFLE9BQWU7O1FBRXRFLE1BQU0sS0FBSyxHQUFHLGNBQU0scUJBQVcsQ0FBQyxLQUFLLENBQUM7WUFDcEMsS0FBSyxFQUFFLDhCQUFtQjtZQUMxQixXQUFXLEVBQUUsYUFBYTtZQUMxQixTQUFTLEVBQUU7Z0JBQ1QsTUFBTSxFQUFFLElBQUksR0FBRyx5QkFBYTtnQkFDNUIsT0FBTyxFQUFFLE9BQU87YUFDakI7U0FDRixDQUFDLENBQUEsQ0FBQztRQUVILEVBQUUsSUFBSSxDQUFDO1FBRVAsTUFBTSxXQUFXLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxhQUFhLEVBQUUsS0FBSyxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsUUFBUSxDQUFDLENBQUM7UUFFOUUsSUFBSSxDQUFDLFdBQVc7WUFBRSxxQkFBTyxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsRUFBQztRQUV6QyxvQkFBTSxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsV0FBVyxFQUFFLENBQUEsQ0FBQztJQUNyQyxDQUFDO0NBQUEsQ0FBQztBQUVGLE1BQU0sMEJBQTBCLEdBQUcsQ0FBQyxJQUFzQyxFQUFTLEVBQUU7SUFDbkYsT0FBTyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsRUFBRSxFQUFFO1FBQ2hDLE9BQU87WUFDTCxPQUFPLEVBQUUsQ0FBQyxDQUFDLEdBQUc7WUFDZCxTQUFTLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLElBQUksRUFBRSxDQUFDLEdBQUcsRUFBRSxFQUFFO2dCQUN2QyxrQ0FBa0M7Z0JBQ2xDLE9BQU8sR0FBRyxDQUFDLEdBQUcsS0FBSyxDQUFDLENBQUMsR0FBRyxDQUFBO1lBQzFCLENBQUMsQ0FBQyxDQUFDO1NBQ0osQ0FBQTtJQUNILENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDTixDQUFDLENBQUM7QUFFVyxRQUFBLHFCQUFxQixHQUFHLEtBQUssSUFBb0IsRUFBRTtJQUM5RCxNQUFNLE9BQU8sR0FBRyxNQUFNLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxrQkFBa0IsRUFBRSxNQUFNLENBQUMsSUFBSSxDQUFDLDhCQUFrQixDQUFDLENBQUMsQ0FBQyxDQUFDO0lBQzlGLE9BQU8sQ0FBQyxDQUFDLFdBQVcsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUNoQyxDQUFDLENBQUM7QUFFSyxLQUFLLFVBQVUsa0JBQWtCLENBQUMsT0FBZTtJQUN0RCxPQUFPLElBQUksT0FBTyxDQUFDLEtBQUssRUFBRSxPQUFPLEVBQUUsTUFBTSxFQUFFLEVBQUU7UUFDM0MsTUFBTSxVQUFVLEdBQVUsRUFBRSxDQUFDO1FBRTdCLHFCQUFxQjtRQUNyQixJQUFJLEtBQUssR0FBRyxxQkFBcUIsQ0FBQyxDQUFDLEVBQUUsOEJBQWtCLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQztRQUVsRSxtQ0FBbUM7UUFDbkMsSUFBSSxTQUFTLEdBQUcsTUFBTSxLQUFLLENBQUMsSUFBSSxFQUFFLENBQUM7UUFFbkMsT0FBTztRQUNQLE1BQU0sZ0JBQWdCLEdBQUcsVUFBVSxDQUFDLEVBQUU7WUFDcEMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQVEsRUFBRSxFQUFFO2dCQUMxQixVQUFVLENBQUMsSUFBSSxDQUFDO29CQUNkLEdBQUcsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssRUFBRSxHQUFHLENBQUM7b0JBQ3ZCLEtBQUssRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRSxHQUFHLENBQUM7aUJBQzVCLENBQUMsQ0FBQztZQUNMLENBQUMsQ0FBQyxDQUFDO1FBQ0wsQ0FBQyxDQUFDO1FBRUYsT0FBTztRQUNQLEdBQUc7WUFDRCxNQUFNLEtBQUssR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRSxTQUFTLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLENBQUM7WUFFekUsSUFBSSxDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUM7Z0JBQ3JCLGdCQUFnQixDQUFDLEtBQUssQ0FBQyxDQUFDO1lBRTFCLElBQUksU0FBUyxDQUFDLEtBQUssQ0FBQyxXQUFXO2dCQUM3QixTQUFTLEdBQUcsTUFBTSxLQUFLLENBQUMsSUFBSSxFQUFFLENBQUM7U0FFbEMsUUFBUSxTQUFTLENBQUMsSUFBSSxLQUFLLEtBQUssRUFBRTtRQUVuQyxNQUFNLFFBQVEsR0FBRyxDQUFDLENBQUMsT0FBTyxDQUFDLEVBQUUsR0FBRyxFQUFFLDRDQUE0QyxFQUFFLENBQUMsQ0FBQztRQUNsRixNQUFNLE1BQU0sR0FBRyxDQUFDLENBQUMsT0FBTyxDQUFDLFVBQVUsRUFBRSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUM7UUFFaEQsTUFBTSxXQUFXLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sRUFBRSxRQUFRLENBQUMsQ0FBQyxDQUFDO1FBQ3ZELE1BQU0sT0FBTyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsV0FBVyxFQUFFLENBQUMsQ0FBTSxFQUFFLEVBQUUsQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQzVELE1BQU0sTUFBTSxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsT0FBTyxFQUFFLEdBQUcsQ0FBQyxFQUFFLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7UUFFbEQsOERBQThEO1FBQzlELE1BQU0sbUJBQW1CLEdBQUcsMEJBQTBCLENBQUMsTUFBTSxDQUFDLENBQUE7UUFDOUQsa0JBQWtCO1FBQ2xCLE9BQU8sQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDO0lBQy9CLENBQUMsQ0FBQyxDQUFDO0FBQ0wsQ0FBQztBQTVDRCxnREE0Q0M7QUFFRCxTQUFnQiwyQkFBMkIsQ0FDekMsU0FBaUIsRUFDakIsV0FBcUQ7SUFFckQsb0RBQW9EO0lBRXBELE1BQU0sNkJBQTZCLEdBQUcsQ0FBQyxDQUF5QyxFQUFFLEVBQUU7UUFDbEYsT0FBTyxDQUFDLENBQUMsU0FBUyxJQUFJLFNBQVMsQ0FBQztJQUNsQyxDQUFDLENBQUE7SUFFRCxNQUFNLFlBQVksR0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDLFdBQVcsRUFBRSw2QkFBNkIsQ0FBQyxDQUFBO0lBQ3pFLE1BQU0sVUFBVSxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsWUFBWSxFQUFFLFNBQVMsQ0FBQyxDQUFBO0lBRWpELE1BQU0sU0FBUyxHQUFHLHNDQUE4QixDQUFDLFdBQVcsRUFBRSxTQUFTLENBQUMsQ0FBQztJQUV6RSxPQUFPO1FBQ0wsU0FBUyxFQUFFLFVBQVU7UUFDckIsUUFBUSxFQUFFLFNBQVM7S0FDcEIsQ0FBQTtBQUVILENBQUM7QUFwQkQsa0VBb0JDIn0=