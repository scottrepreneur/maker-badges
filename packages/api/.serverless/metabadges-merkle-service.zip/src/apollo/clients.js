"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.makerClient = exports.daiClient = exports.makerVaultsClient = exports.governanceClient = void 0;
const cross_fetch_1 = require("cross-fetch");
const apollo_client_1 = require("apollo-client");
const apollo_cache_inmemory_1 = require("apollo-cache-inmemory");
const apollo_link_context_1 = require("apollo-link-context");
const apollo_link_http_1 = require("apollo-link-http");
const MAKER_URL = process.env.MAKER_URL;
const MAKER_USER = process.env.MAKER_USER;
const MAKER_PW = process.env.MAKER_PW;
exports.governanceClient = new apollo_client_1.ApolloClient({
    link: new apollo_link_http_1.HttpLink({
        uri: "https://api.thegraph.com/subgraphs/name/scottrepreneur/maker-governance",
        fetch: cross_fetch_1.default,
    }),
    cache: new apollo_cache_inmemory_1.InMemoryCache(),
});
exports.makerVaultsClient = new apollo_client_1.ApolloClient({
    link: new apollo_link_http_1.HttpLink({
        uri: "https://api.thegraph.com/subgraphs/name/graphitetools/maker",
        fetch: cross_fetch_1.default,
    }),
    cache: new apollo_cache_inmemory_1.InMemoryCache(),
});
exports.daiClient = new apollo_client_1.ApolloClient({
    link: new apollo_link_http_1.HttpLink({
        uri: "https://api.thegraph.com/subgraphs/name/raid-guild/dai-subgraph",
        fetch: cross_fetch_1.default,
    }),
    cache: new apollo_cache_inmemory_1.InMemoryCache(),
});
const authLink = apollo_link_context_1.setContext((_, { headers }) => {
    const token = Buffer.from(`${MAKER_USER}:${MAKER_PW}`).toString("base64");
    return {
        headers: Object.assign(Object.assign({}, headers), { Authorization: `Basic ${token}` }),
    };
});
exports.makerClient = new apollo_client_1.ApolloClient({
    link: authLink.concat(new apollo_link_http_1.HttpLink({
        uri: MAKER_URL,
        fetch: cross_fetch_1.default,
    })),
    cache: new apollo_cache_inmemory_1.InMemoryCache(),
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY2xpZW50cy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uL3NyYy9hcG9sbG8vY2xpZW50cy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7QUFBQSw2Q0FBZ0M7QUFDaEMsaURBQTZDO0FBQzdDLGlFQUFzRDtBQUN0RCw2REFBaUQ7QUFDakQsdURBQTRDO0FBRTVDLE1BQU0sU0FBUyxHQUFXLE9BQU8sQ0FBQyxHQUFHLENBQUMsU0FBVSxDQUFDO0FBQ2pELE1BQU0sVUFBVSxHQUFXLE9BQU8sQ0FBQyxHQUFHLENBQUMsVUFBVyxDQUFDO0FBQ25ELE1BQU0sUUFBUSxHQUFXLE9BQU8sQ0FBQyxHQUFHLENBQUMsUUFBUyxDQUFDO0FBRWxDLFFBQUEsZ0JBQWdCLEdBQUcsSUFBSSw0QkFBWSxDQUFDO0lBQy9DLElBQUksRUFBRSxJQUFJLDJCQUFRLENBQUM7UUFDakIsR0FBRyxFQUNELHlFQUF5RTtRQUMzRSxLQUFLLEVBQUwscUJBQUs7S0FDTixDQUFDO0lBQ0YsS0FBSyxFQUFFLElBQUkscUNBQWEsRUFBRTtDQUMzQixDQUFDLENBQUM7QUFFVSxRQUFBLGlCQUFpQixHQUFHLElBQUksNEJBQVksQ0FBQztJQUNoRCxJQUFJLEVBQUUsSUFBSSwyQkFBUSxDQUFDO1FBQ2pCLEdBQUcsRUFBRSw2REFBNkQ7UUFDbEUsS0FBSyxFQUFMLHFCQUFLO0tBQ04sQ0FBQztJQUNGLEtBQUssRUFBRSxJQUFJLHFDQUFhLEVBQUU7Q0FDM0IsQ0FBQyxDQUFDO0FBRVUsUUFBQSxTQUFTLEdBQUcsSUFBSSw0QkFBWSxDQUFDO0lBQ3hDLElBQUksRUFBRSxJQUFJLDJCQUFRLENBQUM7UUFDakIsR0FBRyxFQUFFLGlFQUFpRTtRQUN0RSxLQUFLLEVBQUwscUJBQUs7S0FDTixDQUFDO0lBQ0YsS0FBSyxFQUFFLElBQUkscUNBQWEsRUFBRTtDQUMzQixDQUFDLENBQUM7QUFFSCxNQUFNLFFBQVEsR0FBRyxnQ0FBVSxDQUFDLENBQUMsQ0FBQyxFQUFFLEVBQUUsT0FBTyxFQUFFLEVBQUUsRUFBRTtJQUM3QyxNQUFNLEtBQUssR0FBRyxNQUFNLENBQUMsSUFBSSxDQUFDLEdBQUcsVUFBVSxJQUFJLFFBQVEsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxDQUFDO0lBQzFFLE9BQU87UUFDTCxPQUFPLGtDQUNGLE9BQU8sS0FDVixhQUFhLEVBQUUsU0FBUyxLQUFLLEVBQUUsR0FDaEM7S0FDRixDQUFDO0FBQ0osQ0FBQyxDQUFDLENBQUM7QUFFVSxRQUFBLFdBQVcsR0FBRyxJQUFJLDRCQUFZLENBQUM7SUFDMUMsSUFBSSxFQUFFLFFBQVEsQ0FBQyxNQUFNLENBQ25CLElBQUksMkJBQVEsQ0FBQztRQUNYLEdBQUcsRUFBRSxTQUFTO1FBQ2QsS0FBSyxFQUFMLHFCQUFLO0tBQ04sQ0FBQyxDQUNIO0lBQ0QsS0FBSyxFQUFFLElBQUkscUNBQWEsRUFBRTtDQUMzQixDQUFDLENBQUMifQ==