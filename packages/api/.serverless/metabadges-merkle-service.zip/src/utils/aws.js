"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getTemplate = exports.addOrUpdateTemplateRecord = void 0;
const { v4: uuidv4 } = require("uuid");
var AWS = require("aws-sdk");
// if (process.env.ENVIRONMENT === "local") {
//   var credentials = new AWS.SharedIniFileCredentials({ profile: "stwoh2" });
//   AWS.config.credentials = credentials;
// }
AWS.config.update({ region: "us-east-1" });
const dynamoDb = new AWS.DynamoDB.DocumentClient();
const DYNAMODB_TABLE = process.env.DYNAMODB_TABLE;
async function addOrUpdateTemplateRecord(_templateId, _addresses, _root, _progress) {
    const timestamp = new Date().getTime();
    const tId = await getIdByTemplate(_templateId);
    // console.log(tId);
    // console.log(addresses);
    if (tId) {
        const params = {
            TableName: DYNAMODB_TABLE,
            Key: { id: tId },
            UpdateExpression: "set addresses = :v, root = :w, progress = :x, updatedAt = :y",
            ExpressionAttributeValues: {
                ":v": JSON.stringify(_addresses != [] ? _addresses.sort() : []),
                ":w": _root,
                ":x": JSON.stringify(_progress),
                ":y": timestamp,
            },
        };
        // console.log(params);
        dynamoDb.update(params, (error, result) => {
            if (error) {
                console.log(error);
            }
            // console.log(result);
            return result;
        });
    }
    else if (tId === null) {
        const params = {
            TableName: DYNAMODB_TABLE,
            Item: {
                id: uuidv4(),
                templateId: _templateId,
                addresses: JSON.stringify(_addresses),
                root: _root,
                progress: JSON.stringify(_root),
                createdAt: timestamp,
                updatedAt: timestamp,
            },
        };
        // console.log(params);
        dynamoDb.put(params, (error, result) => {
            if (error) {
                console.log(error);
            }
            return result;
        });
    }
}
exports.addOrUpdateTemplateRecord = addOrUpdateTemplateRecord;
function getIdByTemplate(templateId) {
    return new Promise((resolve, reject) => {
        const params = {
            TableName: DYNAMODB_TABLE,
            IndexName: "templateId-index",
            KeyConditionExpression: "templateId = :templateId",
            ExpressionAttributeValues: {
                ":templateId": templateId,
            },
        };
        // console.log(params);
        dynamoDb.query(params, (error, result) => {
            if (error) {
                console.log(error);
                reject();
            }
            if (result.Items.length > 0) {
                // console.log("returned: " + result.Items[0]["id"]);
                resolve(result.Items[0]["id"]);
            }
            else {
                resolve(null);
            }
        });
    });
}
function getTemplate(templateId) {
    return new Promise((resolve, reject) => {
        const params = {
            TableName: DYNAMODB_TABLE,
            IndexName: "templateId-index",
            KeyConditionExpression: "templateId = :templateId",
            ExpressionAttributeValues: {
                ":templateId": templateId,
            },
        };
        dynamoDb.query(params, (error, result) => {
            if (error) {
                console.log(error);
                reject();
            }
            if (result.Items.length > 0) {
                const addresses = result.Items[0]["addresses"];
                resolve({
                    addresses: [...JSON.parse(addresses)],
                    root: result.Items[0]["root"],
                    progress: result.Items[0]["progress"],
                });
            }
            else {
                resolve({
                    addresses: [],
                    root: "",
                    progress: {},
                });
            }
        });
    });
}
exports.getTemplate = getTemplate;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYXdzLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vc3JjL3V0aWxzL2F3cy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7QUFBQSxNQUFNLEVBQUUsRUFBRSxFQUFFLE1BQU0sRUFBRSxHQUFHLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQztBQUV2QyxJQUFJLEdBQUcsR0FBRyxPQUFPLENBQUMsU0FBUyxDQUFDLENBQUM7QUFFN0IsNkNBQTZDO0FBQzdDLCtFQUErRTtBQUMvRSwwQ0FBMEM7QUFDMUMsSUFBSTtBQUNKLEdBQUcsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLEVBQUUsTUFBTSxFQUFFLFdBQVcsRUFBRSxDQUFDLENBQUM7QUFFM0MsTUFBTSxRQUFRLEdBQUcsSUFBSSxHQUFHLENBQUMsUUFBUSxDQUFDLGNBQWMsRUFBRSxDQUFDO0FBRW5ELE1BQU0sY0FBYyxHQUFXLE9BQU8sQ0FBQyxHQUFHLENBQUMsY0FBZSxDQUFDO0FBRXBELEtBQUssVUFBVSx5QkFBeUIsQ0FDN0MsV0FBbUIsRUFDbkIsVUFBb0IsRUFDcEIsS0FBYSxFQUNiLFNBQWlCO0lBRWpCLE1BQU0sU0FBUyxHQUFHLElBQUksSUFBSSxFQUFFLENBQUMsT0FBTyxFQUFFLENBQUM7SUFDdkMsTUFBTSxHQUFHLEdBQUcsTUFBTSxlQUFlLENBQUMsV0FBVyxDQUFDLENBQUM7SUFDL0Msb0JBQW9CO0lBQ3BCLDBCQUEwQjtJQUMxQixJQUFJLEdBQUcsRUFBRTtRQUNQLE1BQU0sTUFBTSxHQUFHO1lBQ2IsU0FBUyxFQUFFLGNBQWM7WUFDekIsR0FBRyxFQUFFLEVBQUUsRUFBRSxFQUFFLEdBQUcsRUFBRTtZQUNoQixnQkFBZ0IsRUFDZCw4REFBOEQ7WUFDaEUseUJBQXlCLEVBQUU7Z0JBQ3pCLElBQUksRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLFVBQVUsSUFBSSxFQUFFLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO2dCQUMvRCxJQUFJLEVBQUUsS0FBSztnQkFDWCxJQUFJLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxTQUFTLENBQUM7Z0JBQy9CLElBQUksRUFBRSxTQUFTO2FBQ2hCO1NBQ0YsQ0FBQztRQUNGLHVCQUF1QjtRQUN2QixRQUFRLENBQUMsTUFBTSxDQUFDLE1BQU0sRUFBRSxDQUFDLEtBQVUsRUFBRSxNQUFXLEVBQUUsRUFBRTtZQUNsRCxJQUFJLEtBQUssRUFBRTtnQkFDVCxPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO2FBQ3BCO1lBQ0QsdUJBQXVCO1lBQ3ZCLE9BQU8sTUFBTSxDQUFDO1FBQ2hCLENBQUMsQ0FBQyxDQUFDO0tBQ0o7U0FBTSxJQUFJLEdBQUcsS0FBSyxJQUFJLEVBQUU7UUFDdkIsTUFBTSxNQUFNLEdBQUc7WUFDYixTQUFTLEVBQUUsY0FBYztZQUN6QixJQUFJLEVBQUU7Z0JBQ0osRUFBRSxFQUFFLE1BQU0sRUFBRTtnQkFDWixVQUFVLEVBQUUsV0FBVztnQkFDdkIsU0FBUyxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsVUFBVSxDQUFDO2dCQUNyQyxJQUFJLEVBQUUsS0FBSztnQkFDWCxRQUFRLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUM7Z0JBQy9CLFNBQVMsRUFBRSxTQUFTO2dCQUNwQixTQUFTLEVBQUUsU0FBUzthQUNyQjtTQUNGLENBQUM7UUFDRix1QkFBdUI7UUFDdkIsUUFBUSxDQUFDLEdBQUcsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxLQUFVLEVBQUUsTUFBVyxFQUFFLEVBQUU7WUFDL0MsSUFBSSxLQUFLLEVBQUU7Z0JBQ1QsT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQzthQUNwQjtZQUNELE9BQU8sTUFBTSxDQUFDO1FBQ2hCLENBQUMsQ0FBQyxDQUFDO0tBQ0o7QUFDSCxDQUFDO0FBcERELDhEQW9EQztBQUVELFNBQVMsZUFBZSxDQUFDLFVBQWtCO0lBQ3pDLE9BQU8sSUFBSSxPQUFPLENBQUMsQ0FBQyxPQUFPLEVBQUUsTUFBTSxFQUFFLEVBQUU7UUFDckMsTUFBTSxNQUFNLEdBQUc7WUFDYixTQUFTLEVBQUUsY0FBYztZQUN6QixTQUFTLEVBQUUsa0JBQWtCO1lBQzdCLHNCQUFzQixFQUFFLDBCQUEwQjtZQUNsRCx5QkFBeUIsRUFBRTtnQkFDekIsYUFBYSxFQUFFLFVBQVU7YUFDMUI7U0FDRixDQUFDO1FBQ0YsdUJBQXVCO1FBQ3ZCLFFBQVEsQ0FBQyxLQUFLLENBQUMsTUFBTSxFQUFFLENBQUMsS0FBVSxFQUFFLE1BQVcsRUFBRSxFQUFFO1lBQ2pELElBQUksS0FBSyxFQUFFO2dCQUNULE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUM7Z0JBQ25CLE1BQU0sRUFBRSxDQUFDO2FBQ1Y7WUFDRCxJQUFJLE1BQU0sQ0FBQyxLQUFLLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRTtnQkFDM0IscURBQXFEO2dCQUNyRCxPQUFPLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO2FBQ2hDO2lCQUFNO2dCQUNMLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQzthQUNmO1FBQ0gsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDLENBQUMsQ0FBQztBQUNMLENBQUM7QUFFRCxTQUFnQixXQUFXLENBQ3pCLFVBQWtCO0lBRWxCLE9BQU8sSUFBSSxPQUFPLENBQUMsQ0FBQyxPQUFPLEVBQUUsTUFBTSxFQUFFLEVBQUU7UUFDckMsTUFBTSxNQUFNLEdBQUc7WUFDYixTQUFTLEVBQUUsY0FBYztZQUN6QixTQUFTLEVBQUUsa0JBQWtCO1lBQzdCLHNCQUFzQixFQUFFLDBCQUEwQjtZQUNsRCx5QkFBeUIsRUFBRTtnQkFDekIsYUFBYSxFQUFFLFVBQVU7YUFDMUI7U0FDRixDQUFDO1FBQ0YsUUFBUSxDQUFDLEtBQUssQ0FBQyxNQUFNLEVBQUUsQ0FBQyxLQUFVLEVBQUUsTUFBVyxFQUFFLEVBQUU7WUFDakQsSUFBSSxLQUFLLEVBQUU7Z0JBQ1QsT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQztnQkFDbkIsTUFBTSxFQUFFLENBQUM7YUFDVjtZQUNELElBQUksTUFBTSxDQUFDLEtBQUssQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFO2dCQUMzQixNQUFNLFNBQVMsR0FBRyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDO2dCQUMvQyxPQUFPLENBQUM7b0JBQ04sU0FBUyxFQUFFLENBQUMsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxDQUFDO29CQUNyQyxJQUFJLEVBQUUsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUM7b0JBQzdCLFFBQVEsRUFBRSxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQztpQkFDdEMsQ0FBQyxDQUFDO2FBQ0o7aUJBQU07Z0JBQ0wsT0FBTyxDQUFDO29CQUNOLFNBQVMsRUFBRSxFQUFFO29CQUNiLElBQUksRUFBRSxFQUFFO29CQUNSLFFBQVEsRUFBRSxFQUFFO2lCQUNiLENBQUMsQ0FBQzthQUNKO1FBQ0gsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDLENBQUMsQ0FBQztBQUNMLENBQUM7QUFqQ0Qsa0NBaUNDIn0=