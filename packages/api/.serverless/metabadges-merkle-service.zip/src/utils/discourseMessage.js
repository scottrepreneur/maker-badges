"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const node_fetch_1 = require("node-fetch");
const badges_1 = require("../badges");
const ethers_1 = require("ethers");
const badgeMap_1 = require("./badgeMap");
const lodash_1 = require("lodash");
const DISCOURSE_BADGES_API = process.env.DISCOURSE_BADGES_API;
const DISCOURSE_API_USERNAME = process.env.DISCOURSE_API_USERNAME;
const DISCOURSE_FORUM_URL = process.env.DISCOURSE_FORUM_URL;
const DISCOURSE_USER_BADGES_URL = process.env.DISCOURSE_USER_BADGES_URL;
// ################################
let success = false;
let signer = undefined;
let badgeIds = [];
let badges = [];
let errors = [];
// ################################
// (((((((((((((((((((((((((((((((((((((((((())))))))))))))))))))))))))))))))))))))))))
// (((((((((((((((((((((((((((((((((((((((((())))))))))))))))))))))))))))))))))))))))))
const discourseMessage = async (query) => {
    errors = [];
    badgeIds = [];
    badges = [];
    return new Promise(async (resolve, reject) => {
        if (isBlank(query)) {
            errors.push("Missing query params");
            reject(responseObject());
        }
        if (!VerifyMessage(query)) {
            reject(responseObject());
        }
        badges_1.getBadgesForAddress(signer)
            .then(makerBadges => { query.makerBadges = makerBadges; return query; })
            .then(query => { return getUnlockedBadges(query); })
            .then(query => { return getUserBadges(query); })
            .then(query => { return grantUnlockedBadges(query); })
            .then(keepPromises => { return Promise.all(keepPromises); })
            .then(() => { success = true; resolve(responseObject()); })
            .catch(error => {
            errors.push(error);
            reject(responseObject());
        });
    });
};
// (((((((((((((((((((((((((((((((((((((((((())))))))))))))))))))))))))))))))))))))))))
// (((((((((((((((((((((((((((((((((((((((((())))))))))))))))))))))))))))))))))))))))))
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
const VerifyMessage = async (msg) => {
    try {
        signer = ethers_1.ethers.utils.verifyMessage(msg.username, msg.signature);
        if (signer && signer.toLowerCase() !== msg.address.toLowerCase())
            return false;
    }
    catch (error) {
        errors.push(error);
        return false;
    }
    finally {
        if (signer) {
            return true;
        }
        return false;
    }
};
const grantUnlockedBadges = (query) => {
    if (!query.unlockedBadges) {
        errors.push("No unlocked badges available");
        return;
    }
    if (query.unlockedBadges.length === 0) {
        errors.push("No eligible badges found.");
        return;
    }
    return query.unlockedBadges.map(async (badge) => {
        if (Object.keys(badgeMap_1.badgeMap).includes(badge.id.toString())) {
            // if user already unlocked badge, then move on to the next one
            if (lodash_1.includes(query.userBadges.map(b => b.id), badgeMap_1.badgeMap[badge.id])) {
                errors.push(`Badge [${badgeMap_1.badgeMap[badge.id]}] '${badge.name}' already unlocked for ${query.username}`);
                badges.push(badge);
                return new Promise(resolve => resolve());
            }
            const requestOptions = {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    "Api-Username": `${DISCOURSE_API_USERNAME}`,
                    "Api-Key": `${DISCOURSE_BADGES_API}`,
                },
                body: JSON.stringify({
                    username: query.username,
                    badge_id: badgeMap_1.badgeMap[badge.id],
                }),
            };
            const response = await node_fetch_1.default(`${DISCOURSE_FORUM_URL}`, requestOptions);
            const json = await response.json();
            if (response.status === 200) {
                badgeIds.push(badgeMap_1.badgeMap[badge.id]);
                badges.push(badge);
            }
            return json;
        }
    });
};
const getUnlockedBadges = (query) => { query.unlockedBadges = filterUnlockedBadges(query.makerBadges); return query; };
const getUserBadges = async (query) => { query.userBadges = await getUserBadgesFor(query.username); return query; };
const filterUnlockedBadges = (makerBadges) => {
    return makerBadges.filter(b => { return b.unlocked === 1; });
};
const getUserBadgesFor = (username) => {
    return new Promise(async (resolve) => {
        let userAccount = await node_fetch_1.default(`${DISCOURSE_USER_BADGES_URL}/${username}.json`);
        let userBadges = await userAccount.json();
        resolve(userBadges.badges);
    });
};
const isBlank = value => { return (lodash_1.isEmpty(value) && !lodash_1.isNumber(value)) || lodash_1.isNaN(value); };
const responseObject = () => { return { success, errors, badgeIds, badges }; };
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
exports.default = discourseMessage;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZGlzY291cnNlTWVzc2FnZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uL3NyYy91dGlscy9kaXNjb3Vyc2VNZXNzYWdlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBQUEsMkNBQStCO0FBQy9CLHNDQUFnRDtBQUNoRCxtQ0FBZ0M7QUFDaEMseUNBQXNDO0FBQ3RDLG1DQUE0RDtBQUU1RCxNQUFNLG9CQUFvQixHQUFXLE9BQU8sQ0FBQyxHQUFHLENBQUMsb0JBQXFCLENBQUM7QUFDdkUsTUFBTSxzQkFBc0IsR0FBVyxPQUFPLENBQUMsR0FBRyxDQUFDLHNCQUF1QixDQUFDO0FBQzNFLE1BQU0sbUJBQW1CLEdBQVcsT0FBTyxDQUFDLEdBQUcsQ0FBQyxtQkFBb0IsQ0FBQztBQUNyRSxNQUFNLHlCQUF5QixHQUFXLE9BQU8sQ0FBQyxHQUFHLENBQUMseUJBQTBCLENBQUM7QUFFakYsbUNBQW1DO0FBQ25DLElBQUksT0FBTyxHQUFZLEtBQUssQ0FBQztBQUM3QixJQUFJLE1BQU0sR0FBUSxTQUFTLENBQUM7QUFDNUIsSUFBSSxRQUFRLEdBQVUsRUFBRSxDQUFDO0FBQ3pCLElBQUksTUFBTSxHQUFVLEVBQUUsQ0FBQztBQUN2QixJQUFJLE1BQU0sR0FBVSxFQUFFLENBQUM7QUFDdkIsbUNBQW1DO0FBRW5DLHVGQUF1RjtBQUN2Rix1RkFBdUY7QUFDdkYsTUFBTSxnQkFBZ0IsR0FBRyxLQUFLLEVBQUMsS0FBSyxFQUFDLEVBQUU7SUFDckMsTUFBTSxHQUFHLEVBQUUsQ0FBQztJQUFDLFFBQVEsR0FBRyxFQUFFLENBQUM7SUFBQyxNQUFNLEdBQUcsRUFBRSxDQUFDO0lBRXhDLE9BQU8sSUFBSSxPQUFPLENBQUUsS0FBSyxFQUFFLE9BQU8sRUFBRSxNQUFNLEVBQUUsRUFBRTtRQUU1QyxJQUFJLE9BQU8sQ0FBQyxLQUFLLENBQUMsRUFBRTtZQUFFLE1BQU0sQ0FBQyxJQUFJLENBQUMsc0JBQXNCLENBQUMsQ0FBQztZQUFDLE1BQU0sQ0FBQyxjQUFjLEVBQUUsQ0FBQyxDQUFDO1NBQUU7UUFFdEYsSUFBSSxDQUFDLGFBQWEsQ0FBQyxLQUFLLENBQUMsRUFBRTtZQUFFLE1BQU0sQ0FBQyxjQUFjLEVBQUUsQ0FBQyxDQUFDO1NBQUU7UUFFeEQsNEJBQW1CLENBQUMsTUFBTSxDQUFDO2FBQ3hCLElBQUksQ0FBQyxXQUFXLENBQUksRUFBRSxHQUFHLEtBQUssQ0FBQyxXQUFXLEdBQUcsV0FBVyxDQUFDLENBQUMsT0FBTyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7YUFDMUUsSUFBSSxDQUFDLEtBQUssQ0FBVSxFQUFFLEdBQUcsT0FBTyxpQkFBaUIsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzthQUM1RCxJQUFJLENBQUMsS0FBSyxDQUFVLEVBQUUsR0FBRyxPQUFPLGFBQWEsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzthQUN4RCxJQUFJLENBQUMsS0FBSyxDQUFVLEVBQUUsR0FBRyxPQUFPLG1CQUFtQixDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2FBQzlELElBQUksQ0FBQyxZQUFZLENBQUcsRUFBRSxHQUFHLE9BQU8sT0FBTyxDQUFDLEdBQUcsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzthQUM3RCxJQUFJLENBQUMsR0FBZSxFQUFFLEdBQUcsT0FBTyxHQUFHLElBQUksQ0FBQyxDQUFLLE9BQU8sQ0FBQyxjQUFjLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2FBQzFFLEtBQUssQ0FBQyxLQUFLLENBQVMsRUFBRTtZQUFHLE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7WUFBQyxNQUFNLENBQUMsY0FBYyxFQUFFLENBQUMsQ0FBQztRQUN6RSxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUMsQ0FBQyxDQUFDO0FBQ0wsQ0FBQyxDQUFDO0FBQ0YsdUZBQXVGO0FBQ3ZGLHVGQUF1RjtBQUV2RixvRUFBb0U7QUFDcEUsTUFBTSxhQUFhLEdBQUcsS0FBSyxFQUFDLEdBQUcsRUFBQyxFQUFFO0lBQ2hDLElBQUk7UUFDRixNQUFNLEdBQUcsZUFBTSxDQUFDLEtBQUssQ0FBQyxhQUFhLENBQUMsR0FBRyxDQUFDLFFBQVEsRUFBRSxHQUFHLENBQUMsU0FBUyxDQUFDLENBQUM7UUFFakUsSUFBSSxNQUFNLElBQUksTUFBTSxDQUFDLFdBQVcsRUFBRSxLQUFLLEdBQUcsQ0FBQyxPQUFPLENBQUMsV0FBVyxFQUFFO1lBQzlELE9BQU8sS0FBSyxDQUFDO0tBQ2hCO0lBQ0QsT0FBTyxLQUFLLEVBQUU7UUFBRSxNQUFNLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQUMsT0FBTyxLQUFLLENBQUM7S0FBRTtZQUMzQztRQUNOLElBQUksTUFBTSxFQUFFO1lBQUUsT0FBTyxJQUFJLENBQUM7U0FBRTtRQUU1QixPQUFPLEtBQUssQ0FBQztLQUNkO0FBQ0gsQ0FBQyxDQUFDO0FBRUYsTUFBTSxtQkFBbUIsR0FBRyxDQUFDLEtBQUssRUFBRSxFQUFFO0lBRXBDLElBQUksQ0FBQyxLQUFLLENBQUMsY0FBYyxFQUFFO1FBQUUsTUFBTSxDQUFDLElBQUksQ0FBQyw4QkFBOEIsQ0FBQyxDQUFDO1FBQ3ZFLE9BQU87S0FDUjtJQUVELElBQUksS0FBSyxDQUFDLGNBQWMsQ0FBQyxNQUFNLEtBQUssQ0FBQyxFQUFFO1FBQUUsTUFBTSxDQUFDLElBQUksQ0FBQywyQkFBMkIsQ0FBQyxDQUFDO1FBQ2hGLE9BQU87S0FDUjtJQUVELE9BQU8sS0FBSyxDQUFDLGNBQWMsQ0FBQyxHQUFHLENBQUMsS0FBSyxFQUFDLEtBQUssRUFBQyxFQUFFO1FBQzVDLElBQUksTUFBTSxDQUFDLElBQUksQ0FBQyxtQkFBUSxDQUFDLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsUUFBUSxFQUFFLENBQUMsRUFBRTtZQUV2RCwrREFBK0Q7WUFDL0QsSUFBSSxpQkFBUSxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLG1CQUFRLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUU7Z0JBQ2pFLE1BQU0sQ0FBQyxJQUFJLENBQUMsVUFBVSxtQkFBUSxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsTUFBTSxLQUFLLENBQUMsSUFBSSwwQkFBMEIsS0FBSyxDQUFDLFFBQVEsRUFBRSxDQUFDLENBQUM7Z0JBQ3BHLE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7Z0JBQ25CLE9BQU8sSUFBSSxPQUFPLENBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQyxPQUFPLEVBQUUsQ0FBQyxDQUFDO2FBQzFDO1lBRUQsTUFBTSxjQUFjLEdBQUc7Z0JBQ3JCLE1BQU0sRUFBRSxNQUFNO2dCQUNkLE9BQU8sRUFBRTtvQkFDUCxjQUFjLEVBQUUsa0JBQWtCO29CQUNsQyxjQUFjLEVBQUUsR0FBRyxzQkFBc0IsRUFBRTtvQkFDM0MsU0FBUyxFQUFFLEdBQUcsb0JBQW9CLEVBQUU7aUJBQ3JDO2dCQUNELElBQUksRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDO29CQUNuQixRQUFRLEVBQUUsS0FBSyxDQUFDLFFBQVE7b0JBQ3hCLFFBQVEsRUFBRSxtQkFBUSxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUM7aUJBQzdCLENBQUM7YUFDSCxDQUFDO1lBRUYsTUFBTSxRQUFRLEdBQUcsTUFBTSxvQkFBSyxDQUFDLEdBQUcsbUJBQW1CLEVBQUUsRUFBRSxjQUFjLENBQUMsQ0FBQztZQUN2RSxNQUFNLElBQUksR0FBTyxNQUFNLFFBQVEsQ0FBQyxJQUFJLEVBQUUsQ0FBQztZQUV2QyxJQUFJLFFBQVEsQ0FBQyxNQUFNLEtBQUssR0FBRyxFQUFFO2dCQUFFLFFBQVEsQ0FBQyxJQUFJLENBQUMsbUJBQVEsQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztnQkFBQyxNQUFNLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO2FBQUU7WUFFdkYsT0FBTyxJQUFJLENBQUM7U0FDYjtJQUNILENBQUMsQ0FBQyxDQUFDO0FBQ0wsQ0FBQyxDQUFDO0FBRUYsTUFBTSxpQkFBaUIsR0FBRyxDQUFDLEtBQUssRUFBRSxFQUFFLEdBQUcsS0FBSyxDQUFDLGNBQWMsR0FBRyxvQkFBb0IsQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxPQUFPLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN2SCxNQUFNLGFBQWEsR0FBRyxLQUFLLEVBQUUsS0FBSyxFQUFFLEVBQUUsR0FBRyxLQUFLLENBQUMsVUFBVSxHQUFHLE1BQU0sZ0JBQWdCLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsT0FBTyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFFcEgsTUFBTSxvQkFBb0IsR0FBRyxDQUFDLFdBQVcsRUFBRSxFQUFFO0lBQzNDLE9BQU8sV0FBVyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLE9BQU8sQ0FBQyxDQUFDLFFBQVEsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMvRCxDQUFDLENBQUM7QUFFRixNQUFNLGdCQUFnQixHQUFHLENBQUMsUUFBUSxFQUFFLEVBQUU7SUFDcEMsT0FBTyxJQUFJLE9BQU8sQ0FBQyxLQUFLLEVBQUMsT0FBTyxFQUFDLEVBQUU7UUFDakMsSUFBSSxXQUFXLEdBQUcsTUFBTSxvQkFBSyxDQUFDLEdBQUcseUJBQXlCLElBQUksUUFBUSxPQUFPLENBQUMsQ0FBQztRQUMvRSxJQUFJLFVBQVUsR0FBSSxNQUFNLFdBQVcsQ0FBQyxJQUFJLEVBQUUsQ0FBQztRQUUzQyxPQUFPLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxDQUFDO0lBQzdCLENBQUMsQ0FBQyxDQUFBO0FBQ0osQ0FBQyxDQUFDO0FBRUYsTUFBTSxPQUFPLEdBQUcsS0FBSyxDQUFDLEVBQUUsR0FBRyxPQUFPLENBQUMsZ0JBQU8sQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLGlCQUFRLENBQUMsS0FBSyxDQUFDLENBQUMsSUFBSSxjQUFLLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFFMUYsTUFBTSxjQUFjLEdBQUcsR0FBRyxFQUFFLEdBQUcsT0FBTyxFQUFFLE9BQU8sRUFBRSxNQUFNLEVBQUUsUUFBUSxFQUFFLE1BQU0sRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQy9FLG9FQUFvRTtBQUVwRSxrQkFBZSxnQkFBZ0IsQ0FBQyJ9