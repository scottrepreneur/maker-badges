"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.longestConsecutiveCount = exports.checkForProxyAddresses = exports.checkTemplateProgressForAddressList = exports.checkTemplateAddressesForAddressList = exports.addressListFilteredByFrequency = exports.mapFrequenciesToProgressObject = void 0;
const _ = require("lodash");
const clients_1 = require("../apollo/clients");
const governance_1 = require("../apollo/queries/governance");
function mapFrequenciesToProgressObject(freqMap, frequency) {
    let progressObject = {};
    _.each(freqMap, function (obj) {
        progressObject[obj.address] = obj.frequency / frequency > 1 ? 1 : obj.frequency / frequency;
    });
    return progressObject;
}
exports.mapFrequenciesToProgressObject = mapFrequenciesToProgressObject;
exports.addressListFilteredByFrequency = (list) => {
    return _.map(_.uniq(list), ((x) => {
        return {
            address: x,
            frequency: list.filter(y => y === x).length
        };
    }));
};
async function checkTemplateAddressesForAddressList(addressList, addresses) {
    const match = addressList.map(address => {
        if (!address) {
            return 0;
        }
        if (addresses.includes(address.toLowerCase()) === true) {
            return address.toLowerCase();
        }
        else {
            return null;
        }
    });
    var filtered = match.filter(function (el) {
        return el != null;
    });
    var noDupes = [...new Set(filtered)];
    if (noDupes.length > 0) {
        // console.log('unlocked')
        return noDupes[0];
    }
    return '0x';
}
exports.checkTemplateAddressesForAddressList = checkTemplateAddressesForAddressList;
async function checkTemplateProgressForAddressList(addressList, progress) {
    const match = addressList.map(address => {
        if (progress[address.toLowerCase()]) {
            return progress[address.toLowerCase()];
        }
        return 0;
    });
    return Math.max(...match);
}
exports.checkTemplateProgressForAddressList = checkTemplateProgressForAddressList;
const getProxyAddress = async (query, address) => {
    const result = await clients_1.governanceClient.query({
        query: query,
        variables: {
            address: address
        },
        fetchPolicy: "cache-first",
    }).catch(err => console.log(err));
    // deal with multiple voterRegisty entries
    // deal with multiple proxies
    if (result.data.voterRegistries[0]) {
        return result.data.voterRegistries[0]['voteProxies'][0]['id'];
    }
    else {
        return address;
    }
};
async function checkForProxyAddresses(address) {
    const lookup_types = [
        governance_1.PROXY_HOT_LOOKUP_QUERY,
        governance_1.PROXY_COLD_LOOKUP_QUERY
    ];
    // let addresses = [address]
    return Promise.all(lookup_types.map(query => getProxyAddress(query, address)));
}
exports.checkForProxyAddresses = checkForProxyAddresses;
function longestConsecutiveCount(arr) {
    let chunks = [];
    let prev = 0;
    var sorted = arr.sort(function (a, b) { return a - b; });
    sorted.forEach((current) => {
        if (current - prev != 1)
            chunks.push([]);
        chunks[chunks.length - 1].push(current);
        prev = current;
    });
    chunks.sort((a, b) => b.length - a.length);
    return chunks[0].length;
}
exports.longestConsecutiveCount = longestConsecutiveCount;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi9zcmMvdXRpbHMvaW5kZXgudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBQUEsNEJBQTRCO0FBRTVCLCtDQUFvRDtBQUNwRCw2REFBK0Y7QUFFL0YsU0FBZ0IsOEJBQThCLENBQzVDLE9BQWlELEVBQ2pELFNBQWlCO0lBRWpCLElBQUksY0FBYyxHQUFHLEVBQUUsQ0FBQztJQUV4QixDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRSxVQUFVLEdBQUc7UUFDM0IsY0FBYyxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsR0FBRyxHQUFHLENBQUMsU0FBUyxHQUFHLFNBQVMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLFNBQVMsR0FBRyxTQUFTLENBQUM7SUFDOUYsQ0FBQyxDQUFDLENBQUM7SUFFSCxPQUFPLGNBQWMsQ0FBQztBQUN4QixDQUFDO0FBWEQsd0VBV0M7QUFFWSxRQUFBLDhCQUE4QixHQUFHLENBQUMsSUFBYyxFQUFTLEVBQUU7SUFDdEUsT0FBTyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsRUFBRSxFQUFFO1FBQ2hDLE9BQU87WUFDTCxPQUFPLEVBQUUsQ0FBQztZQUNWLFNBQVMsRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLE1BQU07U0FDNUMsQ0FBQTtJQUNILENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDTixDQUFDLENBQUM7QUFHSyxLQUFLLFVBQVUsb0NBQW9DLENBQ3hELFdBQXFCLEVBQ3JCLFNBQW1CO0lBR25CLE1BQU0sS0FBSyxHQUFVLFdBQVcsQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLEVBQUU7UUFDN0MsSUFBSSxDQUFDLE9BQU8sRUFBRTtZQUNaLE9BQU8sQ0FBQyxDQUFDO1NBQ1Y7UUFDRCxJQUFJLFNBQVMsQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLFdBQVcsRUFBRSxDQUFDLEtBQUssSUFBSSxFQUFFO1lBQ3RELE9BQU8sT0FBTyxDQUFDLFdBQVcsRUFBRSxDQUFDO1NBQzlCO2FBQU07WUFDTCxPQUFPLElBQUksQ0FBQztTQUNiO0lBQ0gsQ0FBQyxDQUFDLENBQUE7SUFDRixJQUFJLFFBQVEsR0FBRyxLQUFLLENBQUMsTUFBTSxDQUFDLFVBQVUsRUFBRTtRQUN0QyxPQUFPLEVBQUUsSUFBSSxJQUFJLENBQUM7SUFDcEIsQ0FBQyxDQUFDLENBQUM7SUFDSCxJQUFJLE9BQU8sR0FBRyxDQUFDLEdBQUksSUFBSSxHQUFHLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQTtJQUVyQyxJQUFJLE9BQU8sQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFO1FBQ3RCLDBCQUEwQjtRQUMxQixPQUFPLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQztLQUNuQjtJQUNELE9BQU8sSUFBSSxDQUFDO0FBQ2QsQ0FBQztBQXpCRCxvRkF5QkM7QUFFTSxLQUFLLFVBQVUsbUNBQW1DLENBQ3ZELFdBQXFCLEVBQ3JCLFFBQVk7SUFFWixNQUFNLEtBQUssR0FBYSxXQUFXLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxFQUFFO1FBQ2hELElBQUksUUFBUSxDQUFDLE9BQU8sQ0FBQyxXQUFXLEVBQUUsQ0FBQyxFQUFFO1lBQ25DLE9BQU8sUUFBUSxDQUFDLE9BQU8sQ0FBQyxXQUFXLEVBQUUsQ0FBQyxDQUFDO1NBQ3hDO1FBQ0QsT0FBTyxDQUFDLENBQUM7SUFDWCxDQUFDLENBQUMsQ0FBQTtJQUNGLE9BQU8sSUFBSSxDQUFDLEdBQUcsQ0FBQyxHQUFHLEtBQUssQ0FBQyxDQUFDO0FBQzVCLENBQUM7QUFYRCxrRkFXQztBQUVELE1BQU0sZUFBZSxHQUFHLEtBQUssRUFBRSxLQUFLLEVBQUUsT0FBTyxFQUFFLEVBQUU7SUFDL0MsTUFBTSxNQUFNLEdBQVEsTUFBTSwwQkFBZ0IsQ0FBQyxLQUFLLENBQUM7UUFDL0MsS0FBSyxFQUFFLEtBQUs7UUFDWixTQUFTLEVBQUU7WUFDVCxPQUFPLEVBQUUsT0FBTztTQUNqQjtRQUNELFdBQVcsRUFBRSxhQUFhO0tBQzNCLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7SUFFbEMsMENBQTBDO0lBQzFDLDZCQUE2QjtJQUU3QixJQUFJLE1BQU0sQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQyxFQUFFO1FBQ2xDLE9BQU8sTUFBTSxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7S0FDL0Q7U0FBTTtRQUNMLE9BQU8sT0FBTyxDQUFDO0tBQ2hCO0FBQ0gsQ0FBQyxDQUFBO0FBRU0sS0FBSyxVQUFVLHNCQUFzQixDQUFDLE9BQWU7SUFDMUQsTUFBTSxZQUFZLEdBQUc7UUFDbkIsbUNBQXNCO1FBQ3RCLG9DQUF1QjtLQUN4QixDQUFBO0lBQ0QsNEJBQTRCO0lBRTVCLE9BQU8sT0FBTyxDQUFDLEdBQUcsQ0FBQyxZQUFZLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsZUFBZSxDQUFDLEtBQUssRUFBRSxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUE7QUFDaEYsQ0FBQztBQVJELHdEQVFDO0FBRUQsU0FBZ0IsdUJBQXVCLENBQUMsR0FBYTtJQUNuRCxJQUFJLE1BQU0sR0FBVSxFQUFFLENBQUM7SUFDdkIsSUFBSSxJQUFJLEdBQVcsQ0FBQyxDQUFDO0lBRXJCLElBQUksTUFBTSxHQUFHLEdBQUcsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLEVBQUUsQ0FBQyxJQUFJLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQSxDQUFDLENBQUMsQ0FBQyxDQUFDO0lBRXhELE1BQU0sQ0FBQyxPQUFPLENBQUMsQ0FBQyxPQUFPLEVBQUUsRUFBRTtRQUN6QixJQUFJLE9BQU8sR0FBRyxJQUFJLElBQUksQ0FBQztZQUFFLE1BQU0sQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUM7UUFDekMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ3hDLElBQUksR0FBRyxPQUFPLENBQUM7SUFDakIsQ0FBQyxDQUFDLENBQUE7SUFFRixNQUFNLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUM7SUFFM0MsT0FBTyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDO0FBQzFCLENBQUM7QUFmRCwwREFlQyJ9