"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.http = void 0;
require("source-map-support").install();
const aws_serverless_express_1 = require("aws-serverless-express");
const app_1 = require("./app");
// NOTE: If you get ERR_CONTENT_DECODING_FAILED in your browser, this is likely
// due to a compressed response (e.g. gzip) which has not been handled correctly
// by aws-serverless-express and/or API Gateway. Add the necessary MIME types to
// binaryMimeTypes below, then redeploy (`npm run package-deploy`)
const binaryMimeTypes = [
// 'application/javascript',
// 'application/json',
// 'application/octet-stream',
// 'application/xml',
// 'font/eot',
// 'font/opentype',
// 'font/otf',
// 'image/jpeg',
// 'image/png',
// 'image/svg+xml',
// 'text/comma-separated-values',
// 'text/css',
// 'text/html',
// 'text/javascript',
// 'text/plain',
// 'text/text',
// 'text/xml',
];
const app = app_1.configureApp();
const server = aws_serverless_express_1.createServer(app, undefined, binaryMimeTypes);
exports.http = (event, context) => aws_serverless_express_1.proxy(server, event, context);
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibGFtYmRhLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vc3JjL2xhbWJkYS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7QUFBQSxPQUFPLENBQUMsb0JBQW9CLENBQUMsQ0FBQyxPQUFPLEVBQUUsQ0FBQztBQUN4QyxtRUFBNkQ7QUFFN0QsK0JBQXFDO0FBRXJDLCtFQUErRTtBQUMvRSxnRkFBZ0Y7QUFDaEYsZ0ZBQWdGO0FBQ2hGLGtFQUFrRTtBQUNsRSxNQUFNLGVBQWUsR0FBYTtBQUNoQyw0QkFBNEI7QUFDNUIsc0JBQXNCO0FBQ3RCLDhCQUE4QjtBQUM5QixxQkFBcUI7QUFDckIsY0FBYztBQUNkLG1CQUFtQjtBQUNuQixjQUFjO0FBQ2QsZ0JBQWdCO0FBQ2hCLGVBQWU7QUFDZixtQkFBbUI7QUFDbkIsaUNBQWlDO0FBQ2pDLGNBQWM7QUFDZCxlQUFlO0FBQ2YscUJBQXFCO0FBQ3JCLGdCQUFnQjtBQUNoQixlQUFlO0FBQ2YsY0FBYztDQUNmLENBQUM7QUFDRixNQUFNLEdBQUcsR0FBRyxrQkFBWSxFQUFFLENBQUM7QUFDM0IsTUFBTSxNQUFNLEdBQUcscUNBQVksQ0FBQyxHQUFHLEVBQUUsU0FBUyxFQUFFLGVBQWUsQ0FBQyxDQUFDO0FBRWhELFFBQUEsSUFBSSxHQUFHLENBQUMsS0FBVSxFQUFFLE9BQWdCLEVBQUUsRUFBRSxDQUNuRCw4QkFBSyxDQUFDLE1BQU0sRUFBRSxLQUFLLEVBQUUsT0FBTyxDQUFDLENBQUMifQ==